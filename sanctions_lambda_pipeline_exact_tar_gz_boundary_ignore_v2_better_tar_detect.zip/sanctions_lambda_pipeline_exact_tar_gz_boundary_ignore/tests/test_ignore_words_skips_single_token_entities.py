import csv
from matcher import build_phrase_index_from_csv, find_exact_matches


def test_ignore_words_skips_is_and_as(tmp_path):
    csv_path = tmp_path / "sanctions.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["sanction_list"])
        w.writeheader()
        w.writerow({"sanction_list": "IS;AS;Jon Julu"})
    phrases, anchor_index, *_ = build_phrase_index_from_csv(
        str(csv_path),
        column_name="sanction_list",
        ignore_words="is,as",
        acronym_max_len=3,
    )

    hits = find_exact_matches("I met Jon Julu today", phrases, anchor_index)
    assert any(h["matchedText"] == "Jon Julu" for h in hits)

    hits2 = find_exact_matches("this IS yellow", phrases, anchor_index)
    assert hits2 == []
