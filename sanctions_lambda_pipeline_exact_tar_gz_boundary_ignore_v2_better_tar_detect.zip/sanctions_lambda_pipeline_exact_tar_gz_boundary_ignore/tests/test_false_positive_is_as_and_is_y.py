import csv
from matcher import build_phrase_index_from_csv, find_exact_matches


def test_is_y_does_not_match_is_yellow(tmp_path):
    csv_path = tmp_path / "sanctions.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["sanction_list"])
        w.writeheader()
        w.writerow({"sanction_list": "IS-Y"})
    phrases, anchor_index, *_ = build_phrase_index_from_csv(str(csv_path), column_name="sanction_list")
    hits = find_exact_matches("this is yellow", phrases, anchor_index)
    assert hits == []


def test_short_all_caps_is_matches_only_uppercase(tmp_path):
    csv_path = tmp_path / "sanctions.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["sanction_list"])
        w.writeheader()
        w.writerow({"sanction_list": "IS"})
    phrases, anchor_index, *_ = build_phrase_index_from_csv(str(csv_path), column_name="sanction_list", acronym_max_len=3)

    assert find_exact_matches("this is yellow", phrases, anchor_index) == []

    hits = find_exact_matches("this IS yellow", phrases, anchor_index)
    assert len(hits) == 1
    assert hits[0]["matchedText"] == "IS"
