"""
s3io.py

S3 I/O + Comprehend tar.gz extraction helpers.

IMPORTANT BUGFIX (why you might get empty results)
--------------------------------------------------
Many Comprehend `output.tar.gz` bundles contain multiple JSON-ish files, e.g.:
- a manifest/metadata JSON (single JSON object; NOT JSONL with Entities)
- one or more JSONL part files (each line is JSON and contains Entities)

If you accidentally select the manifest instead of the JSONL part, you will see:
- Comprehend entities count = 0
- results may be empty (if CSV matching also yields 0)

This version scores extracted members and prefers the file that looks most like
Comprehend JSONL: multiple JSON-per-line records + Entities keys.
"""

from __future__ import annotations

import json
import logging
import tarfile
from pathlib import Path
from typing import Any, List, Optional, Tuple

try:
    import boto3  # type: ignore
except Exception:
    boto3 = None  # type: ignore


def _s3_client():
    """Return a fresh boto3 S3 client (lazily created)."""
    if boto3 is None:
        raise RuntimeError("boto3 is not available. S3 access requires boto3.")
    return boto3.client("s3")


def download_to_tmp(bucket: str, key: str, filename: str, logger: Optional[logging.Logger] = None) -> str:
    """Download an S3 object to `/tmp/<filename>` and return the local path."""
    log = logger or logging.getLogger(__name__)
    local_path = f"/tmp/{filename}"
    log.info("Downloading s3://%s/%s -> %s", bucket, key, local_path)
    _s3_client().download_file(bucket, key, local_path)
    return local_path


def upload_json(bucket: str, key: str, data: Any, logger: Optional[logging.Logger] = None) -> None:
    """Upload a Python object as JSON to S3."""
    log = logger or logging.getLogger(__name__)
    body = json.dumps(data, ensure_ascii=False).encode("utf-8")
    log.info("Uploading JSON to s3://%s/%s (%d bytes)", bucket, key, len(body))
    _s3_client().put_object(Bucket=bucket, Key=key, Body=body, ContentType="application/json")


def _score_candidate_jsonl(path: Path) -> Tuple[int, int]:
    """
    Score a file for being the *actual* Comprehend JSONL output.

    Returns (score, json_records_seen)

    Heuristic (Lambda-safe):
    - Read <=64KB.
    - Split into lines and try json.loads on up to 10 non-empty lines.
    - Count how many are JSON dicts and how many contain Entities-ish keys.
    - Prefer files with multiple JSON records + Entities presence.
    """
    try:
        data = path.read_bytes()[:64 * 1024]
    except Exception:
        return (0, 0)

    text = data.decode("utf-8", errors="ignore")
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    if not lines:
        return (0, 0)

    jsonl_bonus = 2 if len(lines) >= 3 else 0

    records = 0
    entities_lines = 0
    for ln in lines[:10]:
        try:
            obj = json.loads(ln)
        except Exception:
            continue
        if isinstance(obj, dict):
            records += 1
            if any(k in obj for k in ("Entities", "entities", "EntityList", "entityList")):
                entities_lines += 1
            else:
                # Cheap nested signal
                if "Entities" in ln or "entities" in ln:
                    entities_lines += 1

    score = entities_lines * 10 + records + jsonl_bonus
    return (score, records)


def extract_comprehend_tar_gz(
    tar_gz_path: str,
    extract_dir: str = "/tmp/comprehend_extract",
    preferred_member: Optional[str] = None,
    logger: Optional[logging.Logger] = None,
) -> str:
    """
    Extract Comprehend `output.tar.gz` and return the path to the JSONL file inside.

    If preferred_member is provided, we extract that exact member.
    Otherwise, we extract all members and select the best candidate via scoring.
    """
    log = logger or logging.getLogger(__name__)
    extract_path = Path(extract_dir)

    # /tmp can persist across Lambda warm starts; clean to avoid mixing outputs.
    if extract_path.exists():
        for p in sorted(extract_path.rglob("*"), reverse=True):
            if p.is_file():
                p.unlink()
            else:
                try:
                    p.rmdir()
                except Exception:
                    pass
    extract_path.mkdir(parents=True, exist_ok=True)

    log.info("Extracting tar.gz %s -> %s", tar_gz_path, extract_dir)

    with tarfile.open(tar_gz_path, "r:gz") as tf:
        members = tf.getmembers()

        if preferred_member:
            m = next((x for x in members if x.name == preferred_member), None)
            if not m:
                raise ValueError(f"preferred_member '{preferred_member}' not found in tar.gz")
            tf.extract(m, path=extract_dir)
            candidate = extract_path / m.name
            if candidate.is_file() and candidate.stat().st_size > 0:
                log.info("Selected Comprehend member (explicit): %s (bytes=%d)", m.name, candidate.stat().st_size)
                return str(candidate)
            raise ValueError(f"preferred_member '{preferred_member}' extracted but empty/missing")

        tf.extractall(path=extract_dir)

    files = [p for p in extract_path.rglob("*") if p.is_file() and p.stat().st_size > 0]
    if not files:
        raise ValueError("No non-empty files found inside Comprehend tar.gz after extraction.")

    scored = []
    for p in files:
        score, recs = _score_candidate_jsonl(p)
        scored.append((score, recs, p.stat().st_size, p))

    scored.sort(key=lambda t: (t[0], t[1], t[2]), reverse=True)

    for s, recs, sz, p in scored[:5]:
        log.info("Comprehend candidate: %s score=%d jsonRecords=%d bytes=%d", p.name, s, recs, sz)

    best = scored[0][3]
    log.info("Selected Comprehend JSONL file: %s", best.name)
    return str(best)


def read_json_file(path: str) -> Any:
    """Read JSON from disk."""
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def read_jsonl_file(path: str) -> List[Any]:
    """Read JSONL from disk (one JSON object per line)."""
    out: List[Any] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            out.append(json.loads(line))
    return out
