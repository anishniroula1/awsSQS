"""exact_match.py

Exact matching of sanctions phrases against sentence text, with offsets.

What this matcher does
----------------------
- Normalizes the sentence and each sanctions phrase (lowercase, punctuation collapsed).
- Uses an *anchor index* (first token -> phrase ids) to avoid scanning all phrases for every sentence.
- Finds exact, **word-bounded** matches in the normalized sentence.
- Maps normalized offsets back to original string offsets so you get Begin/End offsets.

Why "word-bounded" matching matters
-----------------------------------
It prevents prefix/substring matches.

Example:
- sanctions phrase: "IS-Y" -> normalized "is y"
- sentence:         "is yellow" -> normalized "is yellow"
A naive substring search would match "is y" inside "is yellow" (wrong).
We require boundaries (spaces or start/end), so this is rejected.

Notes about false positives ("IS", "AS", ...)
---------------------------------------------
If your sanctions list contains short tokens that also appear as common English words,
pass those tokens using `IGNORE_WORDS` (handler env var or pipeline arg).
The CSV loader will remove those single-token sanctions entries entirely.
"""

from __future__ import annotations

from typing import Any, Dict, List, Set

from text_norm import normalize_with_map, tokens


def find_sanctions_in_sentence(
    sentence: str,
    phrases: List[Dict[str, Any]],
    anchor_index: Dict[str, List[int]],
    *,
    max_candidates: int = 50_000,
) -> List[Dict[str, Any]]:
    """
    Find exact sanctions matches in a sentence, returning begin/end offsets.

    Parameters
    ----------
    sentence:
        The sentence text to scan.
    phrases:
        Phrase list returned by `load_and_index_sanctions` (dicts with raw/norm/tokens).
    anchor_index:
        Token -> phrase_id list mapping returned by `load_and_index_sanctions`.
    max_candidates:
        Safety cap on number of candidate phrases evaluated for this sentence.
        This exists to keep Lambda runtime predictable.

    Returns
    -------
    list[dict]
        Each dict:
          - entity      : sanctions entity (raw)
          - beginOffset : start offset in original sentence
          - endOffset   : exclusive end offset in original sentence
          - matchedText : substring from sentence
    """
    norm_sentence, norm_map = normalize_with_map(sentence)
    if not norm_sentence:
        return []

    # Tokenize sentence in normalized space to select candidate phrases.
    sent_toks = set(tokens(norm_sentence))
    if not sent_toks:
        return []

    # Candidate selection: phrases whose anchor token appears in the sentence.
    cand_ids: Set[int] = set()
    for t in sent_toks:
        ids = anchor_index.get(t)
        if ids:
            cand_ids.update(ids)
            if len(cand_ids) >= max_candidates:
                break

    if not cand_ids:
        return []

    out: List[Dict[str, Any]] = []

    for pid in cand_ids:
        p = phrases[pid]
        phrase_norm = p["norm"]

        start = 0
        while True:
            pos = norm_sentence.find(phrase_norm, start)
            if pos == -1:
                break

            end = pos + len(phrase_norm)

            # Require word boundaries in normalized space (space or start/end).
            left_ok = (pos == 0) or (norm_sentence[pos - 1] == " ")
            right_ok = (end == len(norm_sentence)) or (norm_sentence[end] == " ")
            if not (left_ok and right_ok):
                start = pos + 1
                continue

            # Map normalized offsets back to original offsets.
            if end > len(norm_map):
                break
            orig_start = norm_map[pos]
            orig_end = norm_map[end - 1] + 1

            out.append({
                "entity": p["raw"],
                "beginOffset": orig_start,
                "endOffset": orig_end,
                "matchedText": sentence[orig_start:orig_end],
            })

            start = pos + 1

    # Deterministic ordering
    out.sort(key=lambda r: (r["beginOffset"], -(r["endOffset"] - r["beginOffset"])))
    return out
