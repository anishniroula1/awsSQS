"""local_runner.py

Local runner (no S3) that executes the same pipeline logic as Lambda.

Use this for quick local testing without deploying to AWS.

Inputs
------
- sanctions CSV: columns `ns1_ids`, `ns1_identity`, `sanctionList`
- mapping JSON: list of {globalId, line, content}
- Comprehend output.tar.gz: contains a JSONL member with records like {Line, Entities:[...]}

Example
-------
python local_runner.py \
  --sanctions-csv ./sanctions.csv \
  --mapping-json ./mapping.json \
  --comprehend-tar ./output.tar.gz \
  --out ./final.json \
  --ignore-words "is,as,the" \
  --return-all-sentences
"""

from __future__ import annotations

import argparse
import json

from logging_utils import configure_logger
from pipeline import run_pipeline_files


def main():
    """CLI entrypoint."""
    ap = argparse.ArgumentParser()
    ap.add_argument("--sanctions-csv", required=True, help="Path to sanctions CSV (ns1_ids/ns1_identity/sanctionList)")
    ap.add_argument("--mapping-json", required=True, help="Path to mapping JSON list (globalId/line/content)")
    ap.add_argument("--comprehend-tar", required=True, help="Path to Comprehend output.tar.gz")
    ap.add_argument("--out", required=True, help="Where to write final output JSON")
    ap.add_argument("--ignore-words", default="", help="Words to ignore as sanctions entities (e.g., 'is,as,the')")
    ap.add_argument("--max-candidates", type=int, default=50000, help="Safety cap to keep runtime predictable")
    ap.add_argument("--return-all-sentences", action="store_true", help="Include sentences even when no entities found")
    ap.add_argument("--comprehend-tar-member", default="", help="Force a specific tar member (optional)")

    args = ap.parse_args()

    log = configure_logger("sanctions-local", "INFO")

    payload = run_pipeline_files(
        sanctions_csv_path=args.sanctions_csv,
        mapping_json_path=args.mapping_json,
        comprehend_tar_gz_path=args.comprehend_tar,
        ignore_words=args.ignore_words or None,
        max_candidates=args.max_candidates,
        return_all_sentences=args.return_all_sentences,
        comprehend_tar_member=args.comprehend_tar_member or None,
        logger=log,
    )

    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)

    log.info("Wrote output to %s", args.out)


if __name__ == "__main__":
    main()
