"""handler.py

AWS Lambda entrypoint.

Downloads from S3 to /tmp:
- sanctions CSV (ns1_ids, ns1_identity, sanctionList)
- mapping JSON list ({globalId, line, content})
- Comprehend output.tar.gz

Runs pipeline and returns a small response + optional full output upload.
"""

from __future__ import annotations

import os
from typing import Any, Dict

from logging_utils import configure_logger
from pipeline import run_pipeline_files
from s3_utils import download_to_tmp, upload_json


def _req(name: str) -> str:
    """Fetch required env var."""
    v = os.getenv(name)
    if not v:
        raise RuntimeError(f"Missing required env var: {name}")
    return v


def lambda_handler(event: Dict[str, Any], context: Any):
    """AWS Lambda handler."""
    log = configure_logger("sanctions-lambda", os.getenv("LOG_LEVEL", "INFO"))

    sanctions_path = download_to_tmp(_req("SANCTIONS_BUCKET"), _req("SANCTIONS_KEY"), "sanctions.csv", logger=log)
    mapping_path = download_to_tmp(_req("MAPPING_BUCKET"), _req("MAPPING_KEY"), "mapping.json", logger=log)
    tar_path = download_to_tmp(_req("COMPREHEND_BUCKET"), _req("COMPREHEND_KEY"), "output.tar.gz", logger=log)

    payload = run_pipeline_files(
        sanctions_csv_path=sanctions_path,
        mapping_json_path=mapping_path,
        comprehend_tar_gz_path=tar_path,
        ignore_words=os.getenv("IGNORE_WORDS") or None,
        max_candidates=int(os.getenv("MAX_CANDIDATES", "50000")),
        return_all_sentences=(os.getenv("RETURN_ALL_SENTENCES", "false").lower() in ("1","true","yes","y")),
        comprehend_tar_member=os.getenv("COMPREHEND_TAR_MEMBER") or None,
        logger=log,
    )

    out_bucket = os.getenv("OUTPUT_BUCKET")
    out_key = os.getenv("OUTPUT_KEY")
    if out_bucket and out_key:
        upload_json(out_bucket, out_key, payload, logger=log)

    preview_n = int(os.getenv("PREVIEW_N", "3"))
    return {
        "meta": payload["meta"],
        "preview": payload["results"][:preview_n],
        "outputWritten": bool(out_bucket and out_key),
    }
