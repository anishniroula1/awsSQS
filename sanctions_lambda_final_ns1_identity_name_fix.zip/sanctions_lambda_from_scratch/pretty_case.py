"""pretty_case.py

Utilities for producing a clean, human-friendly casing for entity text.

Why this exists
---------------
Sometimes entity text comes with messy casing, e.g.:
  "joHN ArKI" -> "John Arki"

The pipeline includes an additional output field:
  - `normalizedText`: a cleaned display form of `text`

Rules (pragmatic)
-----------------
- Preserve short acronyms: "USA" stays "USA" (ALL CAPS and short).
- Otherwise title-case alphabetic segments: "joHN" -> "John".
- Handle apostrophes/hyphens: "o'connor" -> "O'Connor", "jean-paul" -> "Jean-Paul".

This is display-only. Matching/dedupe uses separate normalization.
"""

from __future__ import annotations

import re
from typing import List

_SPLIT_RE = re.compile(r"(\s+)")  # keep whitespace tokens
_WORD_RE = re.compile(r"[A-Za-z]+(?:['-][A-Za-z]+)*")


def _is_acronym(token: str, max_len: int = 5) -> bool:
    """Return True if token looks like a short acronym we should preserve."""
    t = re.sub(r"[^A-Za-z]", "", token)
    return bool(t) and t.isupper() and len(t) <= max_len


def pretty_title(text: str) -> str:
    """
    Convert messy casing into a stable, nice-looking display form.

    Examples
    --------
    - "joHN ArKI" -> "John Arki"
    - "USA" -> "USA"
    - "o'connor" -> "O'Connor"
    """
    if not text:
        return text

    parts: List[str] = _SPLIT_RE.split(text)
    out: List[str] = []

    for part in parts:
        if not part or part.isspace():
            out.append(part)
            continue

        if _is_acronym(part):
            out.append(part)
            continue

        def _fix(m: re.Match) -> str:
            seg = m.group(0)
            return seg[:1].upper() + seg[1:].lower()

        out.append(_WORD_RE.sub(_fix, part))

    return "".join(out)
