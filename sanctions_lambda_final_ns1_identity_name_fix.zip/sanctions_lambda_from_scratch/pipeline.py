"""pipeline.py

Pipeline steps
--------------
1) Parse mapping JSON list: {globalId, line, content}
2) Extract Comprehend output.tar.gz, choose JSONL member, parse entities (PERSON/ORGANIZATION only)
3) Load sanctions CSV (ns1_ids, ns1_identity, sanctionList) and build an anchor index
4) Exact match sanctions phrases against each sentence (with offsets)
5) Merge/dedupe with Comprehend entities and set `sanctionFlag`

This module intentionally keeps `meta` small and focused (no heavy stats).
"""

from __future__ import annotations

import json
import logging
from typing import Any, Dict, List, Optional, Set

from comprehend_parse import parse_jsonl_records, read_jsonl_file
from comprehend_tar import extract_and_select_jsonl
from exact_match import find_sanctions_in_sentence
from mapping_parse import parse_mapping
from merge_entities import merge_for_sentence
from sanctions_csv import load_and_index_sanctions
from text_norm import normalize_with_map


def _norm(text: str) -> str:
    """Normalize string for exact lookups."""
    n, _ = normalize_with_map(text or "")
    return n


def run_pipeline_files(
    *,
    sanctions_csv_path: str,
    mapping_json_path: str,
    comprehend_tar_gz_path: str,
    ignore_words: Optional[str] = None,
    max_candidates: int = 50_000,
    return_all_sentences: bool = False,
    comprehend_tar_member: Optional[str] = None,
    logger: Optional[logging.Logger] = None,
) -> Dict[str, Any]:
    """Run pipeline using local files and return results."""
    log = logger or logging.getLogger(__name__)

    mapping_list = json.load(open(mapping_json_path, "r", encoding="utf-8"))
    line_to_gid, gid_to_content, _ = parse_mapping(mapping_list)

    jsonl_path = extract_and_select_jsonl(
        comprehend_tar_gz_path,
        extract_dir="/tmp/comprehend_extract",
        preferred_member=comprehend_tar_member,
        logger=log,
    )
    records = read_jsonl_file(jsonl_path)
    comp_lines, comp_meta = parse_jsonl_records(records)

    comp_by_gid: Dict[str, List[Dict[str, Any]]] = {}
    for line in comp_lines:
        ln = line.get("lineNumber")
        if ln is None:
            continue
        gid = line_to_gid.get(int(ln))
        if not gid:
            continue
        comp_by_gid.setdefault(gid, []).extend(line.get("entities") or [])

    phrases, anchor_index = load_and_index_sanctions(
        sanctions_csv_path,
        ignore_words=ignore_words,
        logger=log,
    )
    sanctions_norm_set: Set[str] = set(_norm(p["raw"]) for p in phrases if p.get("raw"))

    csv_hits_by_gid: Dict[str, List[Dict[str, Any]]] = {}
    for gid, content in gid_to_content.items():
        hits = find_sanctions_in_sentence(content, phrases, anchor_index, max_candidates=max_candidates)
        if hits:
            csv_hits_by_gid[gid] = hits

    results = []
    for gid, content in gid_to_content.items():
        merged = merge_for_sentence(
            sentence_text=content,
            csv_hits=csv_hits_by_gid.get(gid, []),
            comprehend_ents=comp_by_gid.get(gid, []),
            sanctions_norm_set=sanctions_norm_set,
        )
        if merged or return_all_sentences:
            results.append({"globalId": gid, "content": content, "entities": merged})

    meta = {
        "sentencesTotal": len(gid_to_content),
        "sanctionsPhrases": len(phrases),
        "comprehendEntitiesKept": comp_meta["entitiesTotal"],
        "sentencesInResults": len(results),
    }
    return {"results": results, "meta": meta}
