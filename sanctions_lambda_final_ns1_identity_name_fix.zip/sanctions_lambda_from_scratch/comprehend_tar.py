"""comprehend_tar.py

Extract and locate the *actual* Comprehend JSONL file inside `output.tar.gz`.

Background
----------
Amazon Comprehend async jobs often produce an S3 artifact named `output.tar.gz`.
Inside it, you might see:
- `manifest.json` (a single JSON object with job metadata)
- one or more part files like `part-00000` (JSONL lines, each containing Entities)

Common failure mode
-------------------
If you mistakenly parse the manifest instead of the JSONL parts:
- `comprehendEntitiesTotal` becomes 0
- downstream results can be empty

Solution
--------
We extract all members and score each file by how "JSONL + Entities-like" it is:
- more lines => more likely JSONL
- more lines that parse as JSON dicts
- lines containing `Entities` keys => strongly preferred

This heuristic is fast and Lambda-safe because it only reads a small prefix of each file.
"""

from __future__ import annotations

import gzip
import json
import logging
import tarfile
from pathlib import Path
from typing import Optional, Tuple, List

ENT_KEYS = ("Entities", "entities", "EntityList", "entityList")


def _score_file(path: Path) -> Tuple[int, int]:
    """
    Score a file for being a Comprehend JSONL part file.

    Returns
    -------
    (score, parsed_lines):
        score:
            Higher means "more likely to be the JSONL we want".
        parsed_lines:
            How many lines (from the prefix) parsed as JSON dicts.

    Scoring heuristic (fast, prefix-only)
    ------------------------------------
    - Read up to 128KB
    - Split into non-empty lines
    - Try parsing up to 20 lines as JSON
    - Count how many contain Entities keys
    """
    try:
        data = path.read_bytes()[:128 * 1024]
    except Exception:
        return (0, 0)

    text = data.decode("utf-8", errors="ignore")
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    if not lines:
        return (0, 0)

    # JSONL parts usually have many lines; a manifest is usually 1 line.
    jsonl_bonus = 3 if len(lines) >= 5 else (1 if len(lines) >= 2 else 0)

    parsed = 0
    ent_hits = 0
    for ln in lines[:20]:
        try:
            obj = json.loads(ln)
        except Exception:
            continue

        if isinstance(obj, dict):
            parsed += 1
            if any(k in obj for k in ENT_KEYS):
                ent_hits += 1
            elif "Entities" in ln or "entities" in ln:
                # Cheap nested signal; helps when Entities is inside a wrapper object.
                ent_hits += 1

    score = ent_hits * 20 + parsed + jsonl_bonus
    return (score, parsed)


def extract_and_select_jsonl(
    tar_gz_path: str,
    *,
    extract_dir: str = "/tmp/comprehend_extract",
    preferred_member: Optional[str] = None,
    logger: Optional[logging.Logger] = None,
) -> str:
    """
    Extract output.tar.gz and return the local path to the best JSONL candidate inside.

    Parameters
    ----------
    tar_gz_path:
        Local path to the Comprehend artifact (often `output.tar.gz`).
    extract_dir:
        Directory under /tmp used for extraction.
    preferred_member:
        If provided, force-extract this exact member name (useful if you already know it).
    logger:
        Optional logger.

    Returns
    -------
    str
        Local file path to the chosen JSONL file.

    Fallback behavior
    -----------------
    If the file is not detected as a tar (rare but possible in custom pipelines),
    we attempt a gzip-only extraction into a single output file.
    """
    log = logger or logging.getLogger(__name__)
    out_dir = Path(extract_dir)

    # /tmp persists on warm starts; always clean to avoid mixing two invocations.
    if out_dir.exists():
        for p in sorted(out_dir.rglob("*"), reverse=True):
            if p.is_file():
                p.unlink()
            else:
                try:
                    p.rmdir()
                except Exception:
                    pass
    out_dir.mkdir(parents=True, exist_ok=True)

    # In some pipelines you might get gz-compressed JSONL without a tar wrapper.
    if not tarfile.is_tarfile(tar_gz_path):
        log.warning("Not detected as tarfile; trying gzip fallback: %s", tar_gz_path)
        gz_out = out_dir / "comprehend_output.jsonl"
        with gzip.open(tar_gz_path, "rb") as f_in, open(gz_out, "wb") as f_out:
            f_out.write(f_in.read())
        return str(gz_out)

    with tarfile.open(tar_gz_path, "r:gz") as tf:
        members = tf.getmembers()

        if preferred_member:
            # Force a specific member if the caller knows it (e.g. "part-00000").
            m = next((x for x in members if x.name == preferred_member), None)
            if not m:
                raise ValueError(f"preferred_member not found: {preferred_member}")
            tf.extract(m, path=str(out_dir))
            p = out_dir / m.name
            if not p.is_file() or p.stat().st_size == 0:
                raise ValueError(f"preferred_member extracted but empty: {preferred_member}")
            log.info("Selected tar member (forced): %s", m.name)
            return str(p)

        # Extract all, then score candidates.
        tf.extractall(path=str(out_dir))

    files: List[Path] = [p for p in out_dir.rglob("*") if p.is_file() and p.stat().st_size > 0]
    if not files:
        raise ValueError("No non-empty files extracted")

    scored = []
    for p in files:
        score, parsed = _score_file(p)
        scored.append((score, parsed, p.stat().st_size, p))
    scored.sort(key=lambda t: (t[0], t[1], t[2]), reverse=True)

    # Log the top candidates to make debugging easy in CloudWatch.
    for score, parsed, size, p in scored[:8]:
        log.info("Tar candidate: %s score=%d parsedLines=%d bytes=%d", p.name, score, parsed, size)

    best = scored[0][3]
    log.info("Selected JSONL candidate: %s", best.name)
    return str(best)
