"""text_norm.py

Text normalization + tokenization utilities used for sanctions matching.

Why normalize?
--------------
Sanctions data and sentence text often differ by:
- casing ("EXXON" vs "Exxon")
- punctuation ("Exxon, Inc" vs "Exxon Inc")
- odd separators ("IS-Y" vs "IS Y")

Normalization converts both sides into a comparable form:
- lowercase
- alphanumeric characters kept
- all other characters become single spaces (collapsed)

Offsets requirement
-------------------
The pipeline must return begin/end offsets in the **original sentence**.
To do that we build an index map from each character position in the normalized text
back to the corresponding index in the original string.
"""

from __future__ import annotations

import re
from typing import List, Tuple

# TOKEN_RE extracts alphanumeric "word" tokens used for indexing/candidate selection.
# Examples:
#   "Exxon, Inc" -> ["exxon", "inc"]
#   "IS-Y"       -> ["is", "y"]
TOKEN_RE = re.compile(r"[a-z0-9]+", re.IGNORECASE)


def normalize_with_map(text: str) -> Tuple[str, List[int]]:
    """
    Normalize text and also return a mapping from normalized indices -> original indices.

    Parameters
    ----------
    text:
        Input text (sentence or sanctions entity).

    Returns
    -------
    (normalized_text, idx_map):
        normalized_text:
            Lowercased text where non-alphanumeric spans become a single space.
        idx_map:
            List where ``idx_map[i]`` is the original-string index that produced
            ``normalized_text[i]``.

    Notes
    -----
    - We collapse consecutive punctuation into a single space so normalized strings
      are stable and do not produce weird offset jumps.
    """
    norm_chars: List[str] = []
    idx_map: List[int] = []
    prev_space = False  # True if last appended char was a normalized space

    for i, ch in enumerate(text or ""):
        c = ch.lower()

        if c.isalnum():
            # Keep alphanumeric characters as-is (lowercased).
            norm_chars.append(c)
            idx_map.append(i)
            prev_space = False
        else:
            # Convert any run of non-alnum characters into exactly one space.
            if norm_chars and not prev_space:
                norm_chars.append(" ")
                idx_map.append(i)
                prev_space = True

    # Trim trailing space to avoid boundary mismatches.
    if norm_chars and norm_chars[-1] == " ":
        norm_chars.pop()
        idx_map.pop()

    return "".join(norm_chars), idx_map


def tokens(norm_text: str) -> List[str]:
    """
    Extract alphanumeric tokens from an already-normalized string.

    We use token sets for:
    - building the anchor index (rare token per phrase)
    - selecting candidate phrases for a given sentence
    """
    return TOKEN_RE.findall(norm_text or "")
