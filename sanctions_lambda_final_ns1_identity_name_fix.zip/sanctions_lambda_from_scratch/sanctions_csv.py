"""sanctions_csv.py

Load the sanctions CSV and build a fast exact-match index.

CSV schema (contract)
---------------------
The sanctions CSV contains these columns:

- `ns1_ids`         : sequential ID (not used for matching)
- `ns1_identity`    : either "Individual" or "Entity"
- `sanctionList`    : semicolon-separated list of names

Special handling: Individuals
-----------------------------
If `ns1_identity == "Individual"`, each name in `sanctionList` is stored in
`Last, First` order (with a comma). We convert it to `First Last` before matching.

Example:
- "Smith, John" -> "John Smith"

This conversion is necessary because your sentences and Comprehend entities typically
appear as "First Last".

Return values
-------------
`load_and_index_sanctions()` returns:
- `phrases`: list of prepared phrases (dicts) used by the matcher
- `anchor_index`: dict[token -> list[phrase_index]] used to reduce match work per sentence
"""

from __future__ import annotations

import csv
import logging
import re
from dataclasses import dataclass
from typing import Dict, List, Optional, Set, Tuple

from text_norm import normalize_with_map

TOKEN_RE = re.compile(r"[a-z0-9]+")


@dataclass(frozen=True)
class SanctionPhrase:
    """A single sanction phrase prepared for matching."""
    raw: str
    norm: str
    tokens: Tuple[str, ...]


def _split_semicolon_list(value: str) -> List[str]:
    """Split a semicolon-separated string into trimmed items."""
    if not value:
        return []
    return [x.strip() for x in value.split(";") if x.strip()]


def _flip_last_first(name: str) -> str:
    """
    Convert 'Last, First ...' into 'First ... Last' (best-effort).

    Examples
    --------
    - "Smith, John" -> "John Smith"
    - "Smith, John A." -> "John A. Smith"
    - "Doe, John, Jr." -> "John Jr. Doe"
    """
    if "," not in name:
        return name.strip()

    parts = [p.strip() for p in name.split(",") if p.strip()]
    if len(parts) < 2:
        return name.strip()

    last = parts[0]
    rest = " ".join(parts[1:]).strip()
    return f"{rest} {last}".strip()


def _make_phrase(raw: str) -> Optional[SanctionPhrase]:
    """Normalize and tokenize one raw phrase. Return None if it yields no tokens."""
    norm, _ = normalize_with_map(raw)
    toks = tuple(TOKEN_RE.findall(norm))
    if not toks:
        return None
    return SanctionPhrase(raw=raw, norm=norm, tokens=toks)


def load_and_index_sanctions(
    csv_path: str,
    *,
    ignore_words: Optional[str] = None,
    logger: Optional[logging.Logger] = None,
) -> Tuple[List[Dict], Dict[str, List[int]]]:
    """
    Load sanctions CSV and build phrase list + anchor index.

    Parameters
    ----------
    csv_path:
        Local path to sanctions CSV (ns1_ids, ns1_identity, sanctionList).
    ignore_words:
        Optional ignore list (comma/semicolon/space separated) for single-token entities.
        If a token is in this list, it is never treated as sanctioned.
    logger:
        Optional logger.

    Returns
    -------
    (phrases, anchor_index)
        phrases: list of dicts with keys raw/norm/tokens
        anchor_index: dict[anchorToken] -> list of indices into phrases
    """
    log = logger or logging.getLogger(__name__)

    # Build normalized ignore set.
    ignore_set: Set[str] = set()
    if ignore_words:
        for w in re.split(r"[;,\s]+", ignore_words.strip()):
            if w:
                ignore_set.add(normalize_with_map(w)[0])

    phrases: List[SanctionPhrase] = []

    with open(csv_path, "r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        required = {"ns1_ids", "ns1_identity", "sanctionList"}
        if not reader.fieldnames or not required.issubset(set(reader.fieldnames)):
            raise ValueError(f"CSV must include columns: {sorted(required)}")

        for row in reader:
            identity = (row.get("ns1_identity") or "").strip()
            items = _split_semicolon_list(row.get("sanctionList") or "")
            if not items:
                continue

            is_individual = identity.lower() == "individual"

            for raw in items:
                # Convert person names from "Last, First" -> "First Last"
                raw2 = _flip_last_first(raw) if is_individual else raw.strip()

                phr = _make_phrase(raw2)
                if not phr:
                    continue

                # Ignore generic single-token entities if requested.
                if len(phr.tokens) == 1 and phr.tokens[0] in ignore_set:
                    continue

                phrases.append(phr)

    # Anchor index (first token -> candidate phrases)
    anchor_index: Dict[str, List[int]] = {}
    for idx, phr in enumerate(phrases):
        anchor_index.setdefault(phr.tokens[0], []).append(idx)

    phrases_out = [{"raw": p.raw, "norm": p.norm, "tokens": p.tokens} for p in phrases]
    log.info("Loaded %d sanctions phrases.", len(phrases_out))
    return phrases_out, anchor_index
