import json
import tarfile
from pathlib import Path

from pipeline import run_pipeline_files


def _make_sanctions_csv(path: Path):
    # IMPORTANT: sanctionList contains commas inside names like "Smith, John"
    # so the cell MUST be quoted in real CSV. We model that here.
    path.write_text(
        "ns1_ids,ns1_identity,sanctionList\n"
        "1,Individual,\"Smith, John;ArKI, joHN\"\n"
        "2,Entity,\"Exxon, Inc;Limited Group\"\n"
        "3,Individual,IS;AS;IS-Y\n",
        encoding="utf-8"
    )


def _make_mapping_json(path: Path):
    mapping = [
        {"globalId": "g1", "line": 1, "content": "Payment sent to Exxon, Inc yesterday."},
        {"globalId": "g2", "line": 2, "content": "This is yellow and that is bike."},
        {"globalId": "g3", "line": 3, "content": "Met with joHN ArKI at Limited Group."},
        {"globalId": "g4", "line": 4, "content": "John Smith signed the contract."},
    ]
    path.write_text(json.dumps(mapping), encoding="utf-8")


def _make_comprehend_tar(path: Path):
    part_lines = [
        json.dumps({
            "Line": 1,
            "Entities": [
                {"BeginOffset": 17, "EndOffset": 26, "Score": 0.99, "Text": "Exxon, Inc", "Type": "ORGANIZATION"},
            ]
        }),
        json.dumps({
            "Line": 3,
            "Entities": [
                {"BeginOffset": 9, "EndOffset": 18, "Score": 0.95, "Text": "joHN ArKI", "Type": "PERSON"},
                {"BeginOffset": 22, "EndOffset": 34, "Score": 0.93, "Text": "Limited Group", "Type": "ORGANIZATION"},
            ]
        }),
        json.dumps({
            "Line": 4,
            "Entities": [
                {"BeginOffset": 0, "EndOffset": 10, "Score": 0.97, "Text": "John Smith", "Type": "PERSON"},
            ]
        }),
    ]

    tmp_dir = path.parent / "tmp_tar"
    tmp_dir.mkdir(parents=True, exist_ok=True)
    (tmp_dir / "manifest.json").write_text(json.dumps({"job": "dummy"}), encoding="utf-8")
    (tmp_dir / "part-00000").write_text("\n".join(part_lines) + "\n", encoding="utf-8")

    with tarfile.open(path, "w:gz") as tf:
        tf.add(tmp_dir / "manifest.json", arcname="manifest.json")
        tf.add(tmp_dir / "part-00000", arcname="part-00000")


def test_pipeline_end_to_end_local_files(tmp_path: Path):
    sanctions_csv = tmp_path / "sanctions.csv"
    mapping_json = tmp_path / "mapping.json"
    comprehend_tar = tmp_path / "output.tar.gz"

    _make_sanctions_csv(sanctions_csv)
    _make_mapping_json(mapping_json)
    _make_comprehend_tar(comprehend_tar)

    payload = run_pipeline_files(
        sanctions_csv_path=str(sanctions_csv),
        mapping_json_path=str(mapping_json),
        comprehend_tar_gz_path=str(comprehend_tar),
        ignore_words="is,as,the",
        return_all_sentences=True,
    )

    assert payload["meta"]["sentencesTotal"] == 4

    g1 = next(r for r in payload["results"] if r["globalId"] == "g1")
    assert any(e["sanctionFlag"] and "Exxon" in e["text"] for e in g1["entities"])

    g2 = next(r for r in payload["results"] if r["globalId"] == "g2")
    assert all(not e["sanctionFlag"] for e in g2["entities"])

    g3 = next(r for r in payload["results"] if r["globalId"] == "g3")
    person = next(e for e in g3["entities"] if e.get("type") == "PERSON")
    assert person["normalizedText"] == "John Arki"
    assert person["sanctionFlag"] is True

    g4 = next(r for r in payload["results"] if r["globalId"] == "g4")
    assert any(e["sanctionFlag"] and "John Smith" in e["text"] for e in g4["entities"])
