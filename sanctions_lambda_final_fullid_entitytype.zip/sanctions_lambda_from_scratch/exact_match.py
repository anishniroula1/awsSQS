"""exact_match.py

Exact matching of sanctions phrases against a sentence, returning original offsets.
Propagates sanctions metadata from the phrase record:
- sanctionId (Full ID)
- sanctionEntityType (Entity/Individual)
"""

from __future__ import annotations

from typing import Any, Dict, List, Set

from text_norm import normalize_with_map, tokens


def find_sanctions_in_sentence(
    sentence: str,
    phrases: List[Dict[str, Any]],
    anchor_index: Dict[str, List[int]],
    *,
    max_candidates: int = 50_000,
) -> List[Dict[str, Any]]:
    norm_sentence, norm_map = normalize_with_map(sentence)
    if not norm_sentence:
        return []

    sent_toks = set(tokens(norm_sentence))
    if not sent_toks:
        return []

    cand_ids: Set[int] = set()
    for t in sent_toks:
        ids = anchor_index.get(t)
        if ids:
            cand_ids.update(ids)
            if len(cand_ids) >= max_candidates:
                break
    if not cand_ids:
        return []

    out: List[Dict[str, Any]] = []
    for pid in cand_ids:
        p = phrases[pid]
        phrase_norm = p["norm"]
        start = 0
        while True:
            pos = norm_sentence.find(phrase_norm, start)
            if pos == -1:
                break
            end = pos + len(phrase_norm)

            # Word boundaries in normalized space
            left_ok = (pos == 0) or (norm_sentence[pos-1] == " ")
            right_ok = (end == len(norm_sentence)) or (norm_sentence[end] == " ")
            if not (left_ok and right_ok):
                start = pos + 1
                continue

            if end > len(norm_map):
                break

            orig_start = norm_map[pos]
            orig_end = norm_map[end-1] + 1

            out.append({
                "entity": p["raw"],
                "beginOffset": orig_start,
                "endOffset": orig_end,
                "matchedText": sentence[orig_start:orig_end],
                "sanctionId": p.get("sanctionId"),
                "sanctionEntityType": p.get("sanctionEntityType"),
            })
            start = pos + 1

    out.sort(key=lambda r: (r["beginOffset"], -(r["endOffset"]-r["beginOffset"])))
    return out
