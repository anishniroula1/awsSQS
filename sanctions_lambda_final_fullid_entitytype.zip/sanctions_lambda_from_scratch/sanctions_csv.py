"""sanctions_csv.py

Loads sanctions CSV and builds an anchor index for fast exact matching.

CSV columns (exact headers)
- Full ID
- ns1_entityType            : Entity | Individual
- ns1_formattedFullName     : semicolon-separated names

Individuals: names in 'Last, First' format inside ns1_formattedFullName are converted
to 'First Last' before matching so they align with sentence/Comprehend output.

Each prepared phrase carries:
- sanctionId (Full ID)
- sanctionEntityType (ns1_entityType)
"""

from __future__ import annotations

import csv
import logging
import re
from dataclasses import dataclass
from typing import Dict, List, Optional, Set, Tuple

from text_norm import normalize_with_map

TOKEN_RE = re.compile(r"[a-z0-9]+")


@dataclass(frozen=True)
class SanctionPhrase:
    raw: str
    norm: str
    tokens: Tuple[str, ...]
    sanction_id: str
    entity_type: str


def _split_semicolon_list(value: str) -> List[str]:
    if not value:
        return []
    return [x.strip() for x in value.split(";") if x.strip()]


def _flip_last_first(name: str) -> str:
    if "," not in name:
        return name.strip()
    parts = [p.strip() for p in name.split(",") if p.strip()]
    if len(parts) < 2:
        return name.strip()
    last = parts[0]
    rest = " ".join(parts[1:]).strip()
    return f"{rest} {last}".strip()


def _make_phrase(raw: str, sanction_id: str, entity_type: str) -> Optional[SanctionPhrase]:
    norm, _ = normalize_with_map(raw)
    toks = tuple(TOKEN_RE.findall(norm))
    if not toks:
        return None
    return SanctionPhrase(raw=raw, norm=norm, tokens=toks, sanction_id=sanction_id, entity_type=entity_type)


def load_and_index_sanctions(
    csv_path: str,
    *,
    ignore_words: Optional[str] = None,
    logger: Optional[logging.Logger] = None,
):
    log = logger or logging.getLogger(__name__)

    ignore_set: Set[str] = set()
    if ignore_words:
        for w in re.split(r"[;,\s]+", ignore_words.strip()):
            if w:
                ignore_set.add(normalize_with_map(w)[0])

    phrases: List[SanctionPhrase] = []

    with open(csv_path, "r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        required = {"Full ID", "ns1_entityType", "ns1_formattedFullName"}
        if not reader.fieldnames or not required.issubset(set(reader.fieldnames)):
            raise ValueError(f"CSV must include columns: {sorted(required)}")

        for row in reader:
            sanction_id = str(row.get("Full ID") or "").strip()
            entity_type = str(row.get("ns1_entityType") or "").strip()
            cell = row.get("ns1_formattedFullName") or ""

            if not sanction_id or not entity_type:
                continue

            items = _split_semicolon_list(cell)
            if not items:
                continue

            is_individual = entity_type.lower() == "individual"
            for raw in items:
                raw2 = _flip_last_first(raw) if is_individual else raw.strip()
                phr = _make_phrase(raw2, sanction_id=sanction_id, entity_type=entity_type)
                if not phr:
                    continue
                if len(phr.tokens) == 1 and phr.tokens[0] in ignore_set:
                    continue
                phrases.append(phr)

    anchor_index: Dict[str, List[int]] = {}
    for idx, phr in enumerate(phrases):
        anchor_index.setdefault(phr.tokens[0], []).append(idx)

    phrases_out = [{
        "raw": p.raw,
        "norm": p.norm,
        "tokens": p.tokens,
        "sanctionId": p.sanction_id,
        "sanctionEntityType": p.entity_type,
    } for p in phrases]

    log.info("Loaded %d sanctions phrases.", len(phrases_out))
    return phrases_out, anchor_index
