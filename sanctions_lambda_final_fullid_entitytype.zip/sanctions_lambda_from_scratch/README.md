# Sanctions (CSV) + Comprehend (output.tar.gz) — Exact Match Pipeline (Lambda)

This package is a **fresh rewrite** of the pipeline with better robustness and debugging.

## What it does
1. **Downloads sanctions CSV** from S3 (semicolon-separated entities per row)
2. **Downloads mapping JSON** from S3 with format:
   ```json
   [{"Line": 1, "content": "...", "sentence_id": "..."}, ...]
   ```
3. **Downloads Comprehend `output.tar.gz`** from S3, extracts it, and finds the **real JSONL part file**
   (even if it has no extension and even if a manifest JSON exists in the tar).
4. Parses Comprehend JSONL into normalized:
   ```json
   [{"lineNumber": 1, "entities": [...]}]
   ```
   It **uses real line numbers if present in the JSONL records** (Line/LineNumber/etc). Otherwise it falls back to sequential.
5. Joins Comprehend lineNumber -> sentence_id using mapping.
6. Runs **exact sanctions->sentence matching** with begin/end offsets.
7. Merges:
   - exact CSV sentence matches (always sanctioned)
   - Comprehend entities (sanctioned if overlapping a CSV hit OR if the entity text exactly matches a sanctions entity)
8. Dedupes entities so you don’t get duplicates.
9. Optionally writes output JSON to S3.

## Fixes for false positives like `IS`, `AS`, `IS-Y`
- `IS-Y` no longer matches `"is yellow"` (word-boundary enforcement in normalized matching)
- Short ALL-CAPS sanctions like `IS` are treated as **case-sensitive acronyms**
  - matches `"IS"` but not normal english `"is"`
- You can pass `IGNORE_WORDS` (comma/semicolon/newline separated) to ignore generic single-token entities

## Lambda entrypoint
`handler.lambda_handler`

## Environment variables

### Required
- `SANCTIONS_BUCKET`, `SANCTIONS_KEY`
- `MAPPING_BUCKET`, `MAPPING_KEY`
- `COMPREHEND_BUCKET`, `COMPREHEND_KEY`  (tar.gz)

### Optional
- `SANCTIONS_COLUMN` (default: auto-detect; tries to find a column containing `sanction`)
- `IGNORE_WORDS` (default: empty)
- `ACRONYM_MAX_LEN` (default: 3)  # short ALL-CAPS tokens treated as acronyms
- `MAX_CANDIDATES` (default: 50000) # safety cap for candidate phrases per sentence
- `RETURN_ALL_SENTENCES` (default: false) # if true, includes sentences even if no entities matched
- `COMPREHEND_TAR_MEMBER` (default: auto-detect) # if you want to force a specific member name
- `OUTPUT_BUCKET`, `OUTPUT_KEY` # optional output write

## Local run (no S3)
```bash
pip install -r requirements-dev.txt

python local_runner.py   --sanctions-csv ./sanctions.csv   --mapping-json ./mapping.json   --comprehend-tar ./output.tar.gz   --out ./final.json   --ignore-words "is,as,the"   --acronym-max-len 3
```

## Tests
```bash
pip install -r requirements-dev.txt
pytest -q
```

## Debugging "results is empty"
Check the Lambda response `meta` and logs:
- `comprehendRecords`: how many JSONL records were parsed
- `comprehendEntitiesTotal`: total entities parsed
- `comprehendLinesMatchedToMapping`: how many comprehend records had a matching mapping line
- `sanctionsLoaded`: number of unique sanctions entities loaded from CSV
- `csvMatchTotal`: total exact matches found in sentence text


## Environment variables (Lambda)

- `MAX_CANDIDATES` (default `50000`): Upper bound on how many sanction phrases we will evaluate for a single sentence. This prevents worst-case runtime spikes when a sentence contains very common anchor tokens.
- `PREVIEW_N` (default `3`): How many sentence results are returned inline in the Lambda response. Use `OUTPUT_BUCKET`/`OUTPUT_KEY` to write the full output to S3.
- `IGNORE_WORDS` (optional): Comma/semicolon/whitespace separated list of single-token entities to ignore (e.g. `is,as,the`) to reduce false positives.
- `ACRONYM_MAX_LEN` (default `3`): ALL-CAPS sanctions entries with length <= this are treated as case-sensitive acronyms (so `IS` does NOT match normal `is`).
- `COMPREHEND_TAR_MEMBER` (optional): Force a specific member name inside `output.tar.gz` (advanced debugging).




- Columns: `ns1_ids`, `ns1_identity`, `sanctionList`
- If `ns1_identity` is `Individual`, each name in `sanctionList` is assumed to be `Last, First` and is converted to `First Last`.

## Sanctions CSV schema

- Columns: `Full ID`, `ns1_entityType`, `ns1_formattedFullName`
- If `ns1_entityType` is `Individual`, names are assumed `Last, First` and converted to `First Last`.
