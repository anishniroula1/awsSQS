"""comprehend_parse.py

Parse Comprehend JSONL records into a normalized per-line structure.

Guaranteed input format (per requirements)
------------------------------------------
Each JSONL line is a JSON object containing:
- `Line` (integer line number) OR we fall back to sequential order
- `Entities` (list of entity objects)

Entity object keys are Title Case:
- BeginOffset
- EndOffset (sometimes misspelled EndOfset; we tolerate it)
- Score
- Text
- Type

Filtering
---------
We keep only:
- PERSON
- ORGANIZATION
"""

from __future__ import annotations

import json
from typing import Any, Dict, List, Tuple

ALLOWED_TYPES = {"PERSON", "ORGANIZATION"}


def read_jsonl_file(path: str) -> List[Any]:
    """Read a JSONL file into a list of Python objects (one JSON per line)."""
    out: List[Any] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            out.append(json.loads(line))
    return out


def parse_jsonl_records(records: List[Any]) -> Tuple[List[Dict[str, Any]], Dict[str, int]]:
    """
    Convert raw JSONL records into per-line normalized entities.

    Parameters
    ----------
    records:
        Parsed JSON objects read from the JSONL file.

    Returns
    -------
    (lines, meta)
        lines:
            [{"lineNumber": int, "entities": [ ... ]}, ...]
        meta:
            { "records": int, "entitiesTotal": int, "recordsWithLine": int }
    """
    lines: List[Dict[str, Any]] = []
    total_entities = 0
    with_line = 0

    for i, obj in enumerate(records, start=1):
        if not isinstance(obj, dict):
            continue

        ln = obj.get("Line")
        if ln is not None:
            with_line += 1
            try:
                line_number = int(ln)
            except Exception:
                line_number = i
        else:
            line_number = i

        ents = obj.get("Entities") or []
        norm_ents: List[Dict[str, Any]] = []

        for e in ents:
            if not isinstance(e, dict):
                continue

            etype = e.get("Type")
            if etype not in ALLOWED_TYPES:
                continue

            end_offset = e.get("EndOffset")
            if end_offset is None:
                end_offset = e.get("EndOfset")

            norm_ents.append({
                "Text": e.get("Text"),
                "BeginOffset": e.get("BeginOffset"),
                "EndOffset": end_offset,
                "Type": etype,
                "Score": e.get("Score"),
            })

        total_entities += len(norm_ents)
        lines.append({"lineNumber": line_number, "entities": norm_ents})

    meta = {"records": len(records), "entitiesTotal": total_entities, "recordsWithLine": with_line}
    return lines, meta
