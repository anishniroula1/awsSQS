"""merge_entities.py

Merges CSV sentence matches and Comprehend entities and applies sanction flags.

CSV matches are always sanctioned and include:
- sanctionId (Full ID)
- sanctionEntityType (Entity/Individual)

Comprehend entities are sanctioned if:
- they overlap a CSV span, or
- their normalized text exactly matches a sanctions phrase (sanctions_norm_map).
"""

from __future__ import annotations

from typing import Any, Dict, List, Tuple

from pretty_case import pretty_title
from text_norm import normalize_with_map


def _norm_for_dedupe(t: str) -> str:
    n, _ = normalize_with_map(t or "")
    return n


def _overlap(a0: int, a1: int, b0: int, b1: int) -> bool:
    return a0 < b1 and b0 < a1


def upsert_entity(merged: Dict[Tuple[int,int,str], Dict[str, Any]], rec: Dict[str, Any]) -> None:
    key = (rec["beginOffset"], rec["endOffset"], _norm_for_dedupe(rec["text"]))
    ex = merged.get(key)
    if not ex:
        merged[key] = rec
        return

    ex["sources"] = sorted(set(ex.get("sources", [])) | set(rec.get("sources", [])))
    ex["sanctionFlag"] = bool(ex.get("sanctionFlag") or rec.get("sanctionFlag"))

    if rec.get("sanctionEntity"):
        if (not ex.get("sanctionEntity")) or (len(str(rec["sanctionEntity"])) > len(str(ex["sanctionEntity"]))):
            ex["sanctionEntity"] = rec["sanctionEntity"]

    if not ex.get("sanctionId") and rec.get("sanctionId"):
        ex["sanctionId"] = rec["sanctionId"]
    if not ex.get("sanctionEntityType") and rec.get("sanctionEntityType"):
        ex["sanctionEntityType"] = rec["sanctionEntityType"]

    if not ex.get("normalizedText") and rec.get("normalizedText"):
        ex["normalizedText"] = rec["normalizedText"]

    for k in ("type", "score"):
        if k not in ex and rec.get(k) is not None:
            ex[k] = rec[k]


def merge_for_sentence(
    sentence_text: str,
    csv_hits: List[Dict[str, Any]],
    comprehend_ents: List[Dict[str, Any]],
    sanctions_norm_map: Dict[str, Dict[str, str]],
) -> List[Dict[str, Any]]:
    merged: Dict[Tuple[int,int,str], Dict[str, Any]] = {}

    csv_spans = [(int(h["beginOffset"]), int(h["endOffset"]), h.get("entity"), h.get("sanctionId"), h.get("sanctionEntityType")) for h in csv_hits]

    # CSV matches
    for h in csv_hits:
        b, e = int(h["beginOffset"]), int(h["endOffset"])
        text = h.get("matchedText") or sentence_text[b:e]
        upsert_entity(merged, {
            "text": text,
            "normalizedText": pretty_title(text),
            "beginOffset": b,
            "endOffset": e,
            "sources": ["csv_sentence_match"],
            "sanctionFlag": True,
            "sanctionEntity": h.get("entity"),
            "sanctionId": h.get("sanctionId"),
            "sanctionEntityType": h.get("sanctionEntityType"),
        })

    # Comprehend
    for ent in comprehend_ents:
        text = ent.get("Text") or ""
        try:
            b = int(ent.get("BeginOffset"))
            e = int(ent.get("EndOffset"))
        except Exception:
            continue
        if not text or b < 0 or e <= b:
            continue

        sanction_flag = False
        sanction_entity = sanction_id = sanction_type = None

        for cb, ce, cname, cid, ctype in csv_spans:
            if _overlap(b, e, cb, ce):
                sanction_flag = True
                sanction_entity, sanction_id, sanction_type = cname, cid, ctype
                break

        if not sanction_flag:
            meta = sanctions_norm_map.get(_norm_for_dedupe(text))
            if meta:
                sanction_flag = True
                sanction_entity = meta.get("sanctionEntity")
                sanction_id = meta.get("sanctionId")
                sanction_type = meta.get("sanctionEntityType")

        rec = {
            "text": text,
            "normalizedText": pretty_title(text),
            "beginOffset": b,
            "endOffset": e,
            "sources": ["comprehend"],
            "sanctionFlag": sanction_flag,
            "type": ent.get("Type"),
            "score": ent.get("Score"),
        }
        if sanction_entity:
            rec["sanctionEntity"] = sanction_entity
        if sanction_id:
            rec["sanctionId"] = sanction_id
        if sanction_type:
            rec["sanctionEntityType"] = sanction_type

        upsert_entity(merged, rec)

    out = list(merged.values())
    out.sort(key=lambda r: (r["beginOffset"], -(r["endOffset"]-r["beginOffset"])))
    return out
