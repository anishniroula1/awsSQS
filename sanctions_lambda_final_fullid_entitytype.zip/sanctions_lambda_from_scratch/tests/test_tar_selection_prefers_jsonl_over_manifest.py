import json
import tarfile
from pathlib import Path

from comprehend_tar import extract_and_select_jsonl


def test_tar_selection_prefers_jsonl_over_manifest(tmp_path: Path):
    tar_path = tmp_path / "output.tar.gz"

    tmp_dir = tmp_path / "tar"
    tmp_dir.mkdir()

    # manifest.json is a single JSON object -> should not be selected
    (tmp_dir / "manifest.json").write_text(json.dumps({"job": "meta"}), encoding="utf-8")

    # part file is JSONL with Entities -> should be selected
    part_lines = [
        json.dumps({"Line": 1, "Entities": [{"BeginOffset": 0, "EndOffset": 3, "Score": 1.0, "Text": "ABC", "Type": "ORGANIZATION"}]}),
        json.dumps({"Line": 2, "Entities": [{"BeginOffset": 0, "EndOffset": 3, "Score": 1.0, "Text": "DEF", "Type": "ORGANIZATION"}]}),
    ]
    (tmp_dir / "part-00000").write_text("\n".join(part_lines) + "\n", encoding="utf-8")

    with tarfile.open(tar_path, "w:gz") as tf:
        tf.add(tmp_dir / "manifest.json", arcname="manifest.json")
        tf.add(tmp_dir / "part-00000", arcname="part-00000")

    selected = extract_and_select_jsonl(str(tar_path), extract_dir=str(tmp_path / "extract"))
    assert selected.endswith("part-00000")
