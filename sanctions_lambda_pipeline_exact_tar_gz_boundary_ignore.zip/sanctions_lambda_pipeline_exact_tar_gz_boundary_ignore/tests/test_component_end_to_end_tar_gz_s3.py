import json
import csv
import tarfile
import boto3
from pathlib import Path
from moto import mock_aws

import app


def _put_object(s3, bucket: str, key: str, body: bytes, content_type: str = "application/octet-stream"):
    s3.put_object(Bucket=bucket, Key=key, Body=body, ContentType=content_type)


def _make_tar_gz_with_member(tmp_path: Path, member_name: str, member_bytes: bytes) -> bytes:
    tar_path = tmp_path / "output.tar.gz"
    member_file = tmp_path / "member_content"
    member_file.write_bytes(member_bytes)
    with tarfile.open(tar_path, "w:gz") as tf:
        tf.add(member_file, arcname=member_name)
    return tar_path.read_bytes()


@mock_aws
def test_end_to_end_with_tar_gz_and_false_positive_controls(tmp_path, monkeypatch):
    s3 = boto3.client("s3", region_name="us-east-1")
    s3.create_bucket(Bucket="in-bucket")
    s3.create_bucket(Bucket="out-bucket")

    sanctions_csv = tmp_path / "sanctions.csv"
    with sanctions_csv.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["sanction_list"])
        w.writeheader()
        w.writerow({"sanction_list": "Exxon, Inc;IS;IS-Y;Jon Julu"})
    _put_object(s3, "in-bucket", "sanctions.csv", sanctions_csv.read_bytes(), "text/csv")

    mapping = [
        {"Line": 1, "content": "this is yellow", "sentence_id": "s1"},
        {"Line": 2, "content": "this IS yellow", "sentence_id": "s2"},
        {"Line": 3, "content": "EXXON INC reported earnings.", "sentence_id": "s3"},
    ]
    _put_object(s3, "in-bucket", "mapping.json", json.dumps(mapping).encode("utf-8"), "application/json")

    comp_lines = [
        {"Entities": [{"Text": "yellow", "BeginOffset": 8, "EndOffset": 14, "Type": "OTHER", "Score": 0.5}]},
        {"Entities": [{"Text": "IS", "BeginOffset": 5, "EndOffset": 7, "Type": "OTHER", "Score": 0.5}]},
        {"Entities": [{"Text": "EXXON INC", "BeginOffset": 0, "EndOffset": 9, "Type": "ORGANIZATION", "Score": 0.98}]},
    ]
    jsonl_bytes = ("\n".join(json.dumps(x) for x in comp_lines) + "\n").encode("utf-8")
    tar_bytes = _make_tar_gz_with_member(tmp_path, "part-00000", jsonl_bytes)
    _put_object(s3, "in-bucket", "comprehend/output.tar.gz", tar_bytes, "application/gzip")

    monkeypatch.setenv("SANCTIONS_BUCKET", "in-bucket")
    monkeypatch.setenv("SANCTIONS_KEY", "sanctions.csv")
    monkeypatch.setenv("MAPPING_BUCKET", "in-bucket")
    monkeypatch.setenv("MAPPING_KEY", "mapping.json")
    monkeypatch.setenv("COMPREHEND_BUCKET", "in-bucket")
    monkeypatch.setenv("COMPREHEND_KEY", "comprehend/output.tar.gz")
    monkeypatch.setenv("OUTPUT_BUCKET", "out-bucket")
    monkeypatch.setenv("OUTPUT_KEY", "results.json")
    monkeypatch.setenv("PREVIEW_N", "10")
    monkeypatch.delenv("IGNORE_WORDS", raising=False)

    resp = app.lambda_handler({}, None)
    assert resp["outputWritten"] is True

    out_obj = s3.get_object(Bucket="out-bucket", Key="results.json")
    payload = json.loads(out_obj["Body"].read().decode("utf-8"))
    by_id = {r["sentence_id"]: r for r in payload["results"]}

    # s1: should not be sanctioned due to IS/IS-Y
    if "s1" in by_id:
        assert all(not e.get("sanctionFlag") for e in by_id["s1"]["entities"]), by_id["s1"]["entities"]

    # s2: should include sanctioned IS
    assert "s2" in by_id
    assert any(e.get("sanctionFlag") and e.get("text") == "IS" for e in by_id["s2"]["entities"])

    # s3: Exxon should be sanctioned
    assert "s3" in by_id
    assert any(e.get("sanctionFlag") for e in by_id["s3"]["entities"])
