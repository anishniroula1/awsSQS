# Sanctions + Comprehend Lambda (Exact) — tar.gz + boundary matching + ignore-words

This package provides a **function-based** (no classes) Lambda pipeline that:

- Downloads **sanctions CSV** from S3
- Downloads **mapping JSON** from S3 (`[{Line, content, sentence_id}]`)
- Downloads **Comprehend output.tar.gz** from S3, extracts it, finds the JSONL member file (even if it has **no extension**)
- Converts Comprehend JSONL to normalized structure
- Runs **exact** matching of sanctions phrases -> sentence text with **offsets**
- Merges CSV sentence hits + Comprehend entities
- Sets `sanctionFlag=true` when sanctioned and **dedupes** entities
- Optionally writes final JSON back to S3

## Fixes included (IS/AS/IS-Y false positives)

1) **Word-boundary enforcement in normalized matching**
   Prevents `IS-Y` (normalizes to `is y`) from matching `"is yellow"`.

2) **Short ALL-CAPS sanctions are treated as case-sensitive acronyms**
   Example: sanction `"IS"` matches `"IS"` but NOT normal English `"is"`.
   Controlled by `ACRONYM_MAX_LEN`.

3) **Ignore-words list**
   Pass a list of tokens to ignore entirely (ex: `is,as,the`).
   This list is applied to sanctions entities at load-time: if an entity becomes
   a single token and that token is in `IGNORE_WORDS`, the entity is not loaded.

## Lambda entrypoint
`app.lambda_handler`

## Required env vars
- `SANCTIONS_BUCKET`, `SANCTIONS_KEY`
- `MAPPING_BUCKET`, `MAPPING_KEY`
- `COMPREHEND_BUCKET`, `COMPREHEND_KEY`  (tar.gz key)

## Optional env vars
- `SANCTIONS_COLUMN` (default: `sanction_list`)
- `COMPREHEND_TAR_MEMBER` (default: auto-detect)
- `MAX_CANDIDATES` (default: `50000`)
- `PREVIEW_N` (default: `3`)
- `IGNORE_WORDS` (default: empty)
- `ACRONYM_MAX_LEN` (default: `3`)
- `OUTPUT_BUCKET`, `OUTPUT_KEY`

## Local run (no S3)
```bash
pip install -r requirements-dev.txt

python run_local.py \
  --sanctions-csv ./sanctions.csv \
  --mapping-json ./mapping.json \
  --comprehend-tar ./output.tar.gz \
  --out ./final.json \
  --ignore-words "is,as" \
  --acronym-max-len 3
```

## Tests
```bash
pip install -r requirements-dev.txt
pytest -q
```
