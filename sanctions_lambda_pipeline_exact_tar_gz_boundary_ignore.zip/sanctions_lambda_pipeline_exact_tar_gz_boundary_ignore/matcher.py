"""
matcher.py

Exact matching of sanctions entities against sentence text with offsets.

Key problems solved
-------------------
A) `IS`, `AS` etc. in sanctions list causing English false positives:
   - We treat short ALL-CAPS acronyms as case-sensitive (match original sentence).
B) `IS-Y` normalizes to `is y` which would match the prefix of `is yellow`:
   - We enforce word boundaries in normalized space (space or edge on both sides).
C) Scaling to 100k entities in Lambda:
   - Build an anchor-token index to avoid scanning every phrase against every sentence.
"""

from __future__ import annotations

import csv
import logging
import re
import time
from dataclasses import dataclass
from collections import defaultdict, Counter
from typing import Dict, List, Tuple, Set, Any, Optional

# TOKEN_RE extracts alphanumeric "words" used for indexing and candidate filtering.
# Example: "Exxon, Inc" -> ["Exxon", "Inc"]
TOKEN_RE = re.compile(r"[a-z0-9]+", re.IGNORECASE)


@dataclass(frozen=True)
class Phrase:
    """A sanctions phrase plus precomputed metadata for matching."""
    raw: str
    norm: str
    toks: Tuple[str, ...]
    case_sensitive: bool


def normalize_with_map(s: str) -> Tuple[str, List[int]]:
    """
    Normalize a string and build a mapping from normalized index -> original index.

    We match using normalized text but need original offsets. The returned list
    allows converting normalized match spans back into original string indices.
    """
    norm_chars: List[str] = []
    idx_map: List[int] = []
    prev_space = False

    for i, ch in enumerate(s):
        c = ch.lower()
        if c.isalnum():
            norm_chars.append(c)
            idx_map.append(i)
            prev_space = False
        else:
            # Collapse all non-alnum into a single space run.
            if norm_chars and not prev_space:
                norm_chars.append(" ")
                idx_map.append(i)
                prev_space = True

    # Remove trailing space for consistent matching.
    if norm_chars and norm_chars[-1] == " ":
        norm_chars.pop()
        idx_map.pop()

    return "".join(norm_chars), idx_map


def tokens(norm: str) -> List[str]:
    """Return alphanumeric tokens from a normalized string."""
    return TOKEN_RE.findall(norm)


def _is_short_all_caps_acronym(raw: str, max_len: int) -> bool:
    """
    Return True if `raw` looks like an ALL-CAPS acronym of length <= max_len.

    This is used to avoid false positives where "IS" in sanctions becomes "is" and
    matches normal English. When this returns True, we do a case-sensitive match
    against the original sentence with boundaries.
    """
    r = (raw or "").strip()
    if not r:
        return False
    alnum = re.sub(r"[^A-Za-z0-9]", "", r)
    if not alnum.isalpha():
        return False
    if not (1 <= len(alnum) <= max_len):
        return False
    letters_only = re.sub(r"[^A-Za-z]", "", r)
    return bool(letters_only) and letters_only.upper() == letters_only


def _parse_ignore_words(ignore_words: Optional[str]) -> Set[str]:
    """
    Parse IGNORE_WORDS string into a set of normalized tokens.

    IGNORE_WORDS can be comma/semicolon/newline separated:
      "is,as,the"
      "is;as;the"
      "is\nas\nthe"

    We apply ignore words at sanctions-load time:
    - If a sanctions entity is exactly one token AND that token is in this set,
      we do not load it.
    """
    if not ignore_words:
        return set()
    parts = re.split(r"[;,\n\r\t]+", ignore_words)
    out: Set[str] = set()
    for p in parts:
        p = p.strip()
        if not p:
            continue
        norm, _ = normalize_with_map(p)
        out.update(tokens(norm))
    return out


def build_phrase_index_from_csv(
    csv_path: str,
    column_name: str = "sanction_list",
    *,
    ignore_words: Optional[str] = None,
    acronym_max_len: int = 3,
    logger: logging.Logger | None = None,
):
    """
    Load semicolon-separated sanctions phrases from CSV and build an anchor index.

    Returns:
      phrases: List[Phrase]
      anchor_index: Dict[token -> List[phrase_id]]
      token_freq: Counter (token document frequency across phrases)
      ignore_tokens: Set[str] parsed from IGNORE_WORDS
    """
    log = logger or logging.getLogger(__name__)
    t0 = time.time()

    ignore_tokens = _parse_ignore_words(ignore_words)

    seen_norm: Set[str] = set()
    phrases: List[Phrase] = []
    token_freq = Counter()

    with open(csv_path, "r", newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames or column_name not in reader.fieldnames:
            raise ValueError(f"CSV missing column '{column_name}'. Found columns: {reader.fieldnames}")

        rows = 0
        raw_entities = 0

        for row in reader:
            rows += 1
            cell = (row.get(column_name) or "").strip()
            if not cell:
                continue

            for item in cell.split(";"):
                raw_entities += 1
                raw = item.strip()
                if not raw:
                    continue

                # Decide case-sensitive matching for short all-caps acronyms like "IS".
                case_sensitive = _is_short_all_caps_acronym(raw, max_len=acronym_max_len)

                norm, _ = normalize_with_map(raw)
                if not norm or norm in seen_norm:
                    continue

                toks = tuple(tokens(norm))
                if not toks:
                    continue

                # IGNORE_WORDS rule: skip single-token entities like "is", "as", "the".
                if len(toks) == 1 and toks[0] in ignore_tokens:
                    continue

                seen_norm.add(norm)
                phrases.append(Phrase(raw=raw, norm=norm, toks=toks, case_sensitive=case_sensitive))
                token_freq.update(set(toks))

    # Anchor-token index:
    # For each phrase, choose its rarest token as an anchor.
    # Then, for a sentence, only evaluate phrases whose anchor token appears.
    anchor_index: Dict[str, List[int]] = defaultdict(list)
    for i, p in enumerate(phrases):
        anchor = min(set(p.toks), key=lambda t: token_freq.get(t, 10**9))
        anchor_index[anchor].append(i)

    log.info(
        "Sanctions index built: rows=%d raw_entities=%d unique=%d anchors=%d ignoreTokens=%d (%.2fs)",
        rows, raw_entities, len(phrases), len(anchor_index), len(ignore_tokens), time.time() - t0
    )
    return phrases, dict(anchor_index), token_freq, ignore_tokens


def _find_case_sensitive_hits(sentence: str, raw: str):
    """
    Find case-sensitive matches of `raw` using alnum boundaries in the original sentence.

    This avoids matching 'IS' inside 'ISLAND'.
    """
    pattern = re.compile(rf"(?<![A-Za-z0-9]){re.escape(raw)}(?![A-Za-z0-9])")
    for m in pattern.finditer(sentence):
        yield m.start(), m.end()


def find_exact_matches(
    sentence: str,
    phrases: List[Phrase],
    anchor_index: Dict[str, List[int]],
    *,
    max_candidates: int = 50_000,
) -> List[Dict[str, Any]]:
    """
    Find phrase matches in a sentence and return begin/end offsets.

    max_candidates is a safety limit: if a sentence contains very common tokens,
    candidate phrases could explode. This cap keeps runtime predictable in Lambda.
    """
    sent_norm, sent_map = normalize_with_map(sentence)
    if not sent_norm:
        return []

    sent_toks = set(tokens(sent_norm))
    if not sent_toks:
        return []

    cand_ids: Set[int] = set()
    for t in sent_toks:
        ids = anchor_index.get(t)
        if ids:
            cand_ids.update(ids)
            if len(cand_ids) >= max_candidates:
                break

    if not cand_ids:
        return []

    results: List[Dict[str, Any]] = []

    for pid in cand_ids:
        p = phrases[pid]

        # Case-sensitive acronym path (e.g., "IS").
        if p.case_sensitive:
            for b, e in _find_case_sensitive_hits(sentence, p.raw):
                results.append({
                    "entity": p.raw,
                    "beginOffset": b,
                    "endOffset": e,
                    "matchedText": sentence[b:e],
                })
            continue

        # Normal path: match in normalized text with word-boundary enforcement.
        start = 0
        while True:
            pos = sent_norm.find(p.norm, start)
            if pos == -1:
                break
            end = pos + len(p.norm)

            # Word-boundary enforcement (prevents prefix matches like "is y" in "is yellow").
            left_ok = (pos == 0) or (sent_norm[pos - 1] == " ")
            right_ok = (end == len(sent_norm)) or (sent_norm[end] == " ")
            if not (left_ok and right_ok):
                start = pos + 1
                continue

            # Convert normalized span -> original offsets using the index map.
            if end > len(sent_map):
                break
            orig_start = sent_map[pos]
            orig_end = sent_map[end - 1] + 1

            results.append({
                "entity": p.raw,
                "beginOffset": orig_start,
                "endOffset": orig_end,
                "matchedText": sentence[orig_start:orig_end],
            })
            start = pos + 1

    results.sort(key=lambda r: (r["beginOffset"], -(r["endOffset"] - r["beginOffset"])))
    return results
