"""logging_utils.py

Central logging configuration used by both AWS Lambda and the local runner.

Why a separate module?
- Lambda may reuse the same execution environment for multiple invocations ("warm starts").
  If you add handlers repeatedly you will get duplicate log lines.
- Tests and local development should see the same log format as Lambda for parity.
"""

from __future__ import annotations

import logging


def configure_logger(name: str, level: str = "INFO") -> logging.Logger:
    """
    Configure and return a logger with a consistent format.

    Parameters
    ----------
    name:
        Logger name. Use different names per subsystem if you want separate log filters.
    level:
        String log level ("DEBUG", "INFO", ...). Anything unknown falls back to INFO.

    Returns
    -------
    logging.Logger
        A configured logger.

    Notes
    -----
    - We call ``logging.basicConfig`` only if the logger has no handlers yet. This prevents
      duplicate handlers during Lambda warm starts and during test runs.
    - We intentionally do not attach custom handlers; CloudWatch captures stdout/stderr.
    """
    log = logging.getLogger(name)

    # In Lambda, the environment can be reused. If we configure handlers multiple times,
    # every subsequent invocation prints duplicate lines.
    if not log.handlers:
        logging.basicConfig(
            level=getattr(logging, level.upper(), logging.INFO),
            format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        )

    return log
