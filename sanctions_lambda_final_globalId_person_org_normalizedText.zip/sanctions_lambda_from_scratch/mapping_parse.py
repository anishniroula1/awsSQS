"""mapping_parse.py

Parse the mapping JSON used to connect Comprehend line numbers to your global IDs.

Guaranteed input format
-----------------------
Mapping JSON is always a **list** of objects with these exact keys:

  {
    "globalId": "abc123",
    "line": 1,
    "content": "the sentence text"
  }

Outputs
-------
1) ``line_to_gid``: dict[int -> globalId]
2) ``gid_to_content``: dict[globalId -> sentence text]
3) ``stats``: counters for logging/debugging
"""

from __future__ import annotations

from typing import Any, Dict, Tuple


def parse_mapping(mapping_list: Any) -> Tuple[Dict[int, str], Dict[str, str], Dict[str, int]]:
    """
    Parse the mapping list and return lookup structures + stats.

    Parameters
    ----------
    mapping_list:
        Expected to be a list[dict] with keys: globalId, line, content.

    Returns
    -------
    (line_to_gid, gid_to_content, stats)

    Raises
    ------
    ValueError
        If the mapping JSON is not a list.
    """
    if not isinstance(mapping_list, list):
        raise ValueError("Mapping JSON must be a list of objects")

    line_to_gid: Dict[int, str] = {}
    gid_to_content: Dict[str, str] = {}

    loaded = 0
    min_line = None
    max_line = None

    for it in mapping_list:
        if not isinstance(it, dict):
            continue

        gid = it.get("globalId")
        line = it.get("line")
        content = it.get("content")

        if gid is None or line is None or content is None:
            continue

        try:
            ln = int(line)
        except Exception:
            continue

        gid_s = str(gid)
        line_to_gid[ln] = gid_s
        gid_to_content[gid_s] = str(content)

        loaded += 1
        min_line = ln if min_line is None else min(min_line, ln)
        max_line = ln if max_line is None else max(max_line, ln)

    stats = {
        "mappingItems": len(mapping_list),
        "mappingLoaded": loaded,
        "mappingMinLine": min_line or 0,
        "mappingMaxLine": max_line or 0,
    }
    return line_to_gid, gid_to_content, stats
