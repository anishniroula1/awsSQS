"""handler.py

AWS Lambda entrypoint.

Downloads:
- Sanctions CSV from S3
- Mapping JSON (list with globalId/line/content) from S3
- Comprehend output.tar.gz from S3

Runs pipeline and returns:
- meta (counters)
- preview (first PREVIEW_N results)

Optionally uploads the full output JSON to S3 if OUTPUT_BUCKET/OUTPUT_KEY are provided.
"""

from __future__ import annotations

import os
from typing import Any, Dict

from logging_utils import configure_logger
from pipeline import run_pipeline_files
from s3_utils import download_to_tmp, upload_json


def _req(name: str) -> str:
    """Fetch a required env var or raise."""
    v = os.getenv(name)
    if not v:
        raise RuntimeError(f"Missing required env var: {name}")
    return v


def _opt(name: str, default: str = "") -> str:
    """Fetch an optional env var with a default."""
    v = os.getenv(name)
    return v if v is not None and v != "" else default


def lambda_handler(event: Dict[str, Any], context: Any):
    """AWS Lambda handler."""
    log = configure_logger("sanctions-lambda", _opt("LOG_LEVEL", "INFO"))

    sanctions_bucket = _req("SANCTIONS_BUCKET")
    sanctions_key = _req("SANCTIONS_KEY")
    mapping_bucket = _req("MAPPING_BUCKET")
    mapping_key = _req("MAPPING_KEY")
    comprehend_bucket = _req("COMPREHEND_BUCKET")
    comprehend_key = _req("COMPREHEND_KEY")

    sanctions_column = os.getenv("SANCTIONS_COLUMN") or None
    ignore_words = os.getenv("IGNORE_WORDS") or None
    acronym_max_len = int(_opt("ACRONYM_MAX_LEN", "3"))
    max_candidates = int(_opt("MAX_CANDIDATES", "50000"))
    return_all = _opt("RETURN_ALL_SENTENCES", "false").lower() in ("1", "true", "yes", "y")
    tar_member = os.getenv("COMPREHEND_TAR_MEMBER") or None

    out_bucket = os.getenv("OUTPUT_BUCKET")
    out_key = os.getenv("OUTPUT_KEY")

    sanctions_path = download_to_tmp(sanctions_bucket, sanctions_key, "sanctions.csv", logger=log)
    mapping_path = download_to_tmp(mapping_bucket, mapping_key, "mapping.json", logger=log)
    tar_path = download_to_tmp(comprehend_bucket, comprehend_key, "output.tar.gz", logger=log)

    payload = run_pipeline_files(
        sanctions_csv_path=sanctions_path,
        mapping_json_path=mapping_path,
        comprehend_tar_gz_path=tar_path,
        sanctions_column=sanctions_column,
        ignore_words=ignore_words,
        acronym_max_len=acronym_max_len,
        max_candidates=max_candidates,
        return_all_sentences=return_all,
        comprehend_tar_member=tar_member,
        logger=log,
    )

    if out_bucket and out_key:
        upload_json(out_bucket, out_key, payload, logger=log)

    preview_n = int(_opt("PREVIEW_N", "3"))
    return {
        "meta": payload["meta"],
        "preview": payload["results"][:preview_n],
        "outputWritten": bool(out_bucket and out_key),
    }
