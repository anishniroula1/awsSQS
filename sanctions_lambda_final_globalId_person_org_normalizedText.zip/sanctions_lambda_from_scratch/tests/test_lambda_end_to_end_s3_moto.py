import json
import csv
import tarfile
import boto3
from pathlib import Path
import pytest

moto = pytest.importorskip("moto")
from moto import mock_aws

import handler


def _make_tar_bytes(tmp_path: Path, member_name: str, member_text: str) -> bytes:
    """Create a minimal output.tar.gz containing a JSONL member."""
    member = tmp_path / "member"
    member.write_text(member_text, encoding="utf-8")
    tar_path = tmp_path / "output.tar.gz"
    with tarfile.open(tar_path, "w:gz") as tf:
        man = tmp_path / "manifest.json"
        man.write_text(json.dumps({"job": "comprehend"}), encoding="utf-8")
        tf.add(man, arcname="manifest.json")
        tf.add(member, arcname=member_name)
    return tar_path.read_bytes()


@mock_aws
def test_lambda_smoke(tmp_path, monkeypatch):
    """Component-style smoke test: S3 downloads + handler + pipeline all wired."""
    s3 = boto3.client("s3", region_name="us-east-1")
    s3.create_bucket(Bucket="in")
    s3.create_bucket(Bucket="out")

    # --- Sanctions CSV (semicolon separated) ---
    sanctions_csv = tmp_path / "sanctions.csv"
    with sanctions_csv.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["sanction_list"])
        w.writeheader()
        w.writerow({"sanction_list": "Jon Julu;Exxon, Inc;IS-Y;IS"})
    s3.put_object(Bucket="in", Key="sanctions.csv", Body=sanctions_csv.read_bytes())

    # --- Mapping JSON (list of {globalId,line,content}) ---
    mapping = [
        {"globalId": "g1", "line": 1, "content": "this IS yellow"},
        {"globalId": "g2", "line": 2, "content": "I met Jon Julu yesterday."},
    ]
    s3.put_object(Bucket="in", Key="mapping.json", Body=json.dumps(mapping).encode("utf-8"))

    # --- Comprehend JSONL in tar.gz ---
    jsonl = (
        json.dumps({"Line": 1, "Entities": [
            {"Text": "IS", "BeginOffset": 5, "EndOffset": 7, "Type": "ORGANIZATION", "Score": 0.9},
        ]}) + "\n" +
        json.dumps({"Line": 2, "Entities": [
            {"Text": "Jon Julu", "BeginOffset": 6, "EndOffset": 13, "Type": "PERSON", "Score": 0.95},
        ]}) + "\n"
    )
    tar_bytes = _make_tar_bytes(tmp_path, "part-00000", jsonl)
    s3.put_object(Bucket="in", Key="output.tar.gz", Body=tar_bytes)

    # --- Handler env vars ---
    monkeypatch.setenv("SANCTIONS_BUCKET", "in")
    monkeypatch.setenv("SANCTIONS_KEY", "sanctions.csv")
    monkeypatch.setenv("MAPPING_BUCKET", "in")
    monkeypatch.setenv("MAPPING_KEY", "mapping.json")
    monkeypatch.setenv("COMPREHEND_BUCKET", "in")
    monkeypatch.setenv("COMPREHEND_KEY", "output.tar.gz")
    monkeypatch.setenv("OUTPUT_BUCKET", "out")
    monkeypatch.setenv("OUTPUT_KEY", "final.json")
    monkeypatch.setenv("PREVIEW_N", "10")

    resp = handler.lambda_handler({}, None)
    assert resp["outputWritten"] is True

    # Verify output exists in S3 and includes globalId field
    obj = s3.get_object(Bucket="out", Key="final.json")
    payload = json.loads(obj["Body"].read().decode("utf-8"))

    assert payload["results"][0]["globalId"] in {"g1", "g2"}
    # g1 should be sanctioned due to CSV sentence match of uppercase acronym "IS"
    g1 = next(r for r in payload["results"] if r["globalId"] == "g1")
    assert any(e.get("sanctionFlag") for e in g1["entities"])
