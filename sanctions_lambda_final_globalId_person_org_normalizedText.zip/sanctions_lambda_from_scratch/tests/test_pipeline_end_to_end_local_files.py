import json
import tarfile
from pathlib import Path

from pipeline import run_pipeline_files


def _make_sanctions_csv(path: Path):
    # One column includes semicolon-separated entities.
    path.write_text(
        "id,sanction_list\n"
        "1,Exxon, Inc;Limited Group;Jon Julu\n"
        "2,IS;AS;IS-Y\n",
        encoding="utf-8"
    )


def _make_mapping_json(path: Path):
    # Contract: mapping is always list of {globalId,line,content}
    mapping = [
        {"globalId": "g1", "line": 1, "content": "Payment sent to Exxon, Inc yesterday."},
        {"globalId": "g2", "line": 2, "content": "This is yellow and that is bike."},
        {"globalId": "g3", "line": 3, "content": "Met with joHN ArKI at Limited Group."},
    ]
    path.write_text(json.dumps(mapping), encoding="utf-8")


def _make_comprehend_tar(path: Path):
    # Build a tar.gz with a manifest.json (single json) + a part file with JSONL lines.
    part_lines = [
        json.dumps({
            "Line": 1,
            "Entities": [
                {"BeginOffset": 17, "EndOffset": 26, "Score": 0.99, "Text": "Exxon, Inc", "Type": "ORGANIZATION"},
                # A non-person/org entity should be filtered out
                {"BeginOffset": 0, "EndOffset": 7, "Score": 0.5, "Text": "Payment", "Type": "OTHER"},
            ]
        }),
        json.dumps({
            "Line": 3,
            "Entities": [
                {"BeginOffset": 5, "EndOffset": 14, "Score": 0.95, "Text": "joHN ArKI", "Type": "PERSON"},
                {"BeginOffset": 18, "EndOffset": 30, "Score": 0.93, "Text": "Limited Group", "Type": "ORGANIZATION"},
            ]
        }),
    ]

    manifest = {"job": "dummy", "note": "this is not jsonl"}

    tmp_dir = path.parent / "tmp_tar"
    tmp_dir.mkdir(parents=True, exist_ok=True)
    (tmp_dir / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
    (tmp_dir / "part-00000").write_text("\n".join(part_lines) + "\n", encoding="utf-8")

    with tarfile.open(path, "w:gz") as tf:
        tf.add(tmp_dir / "manifest.json", arcname="manifest.json")
        tf.add(tmp_dir / "part-00000", arcname="part-00000")


def test_pipeline_end_to_end_local_files(tmp_path: Path):
    sanctions_csv = tmp_path / "sanctions.csv"
    mapping_json = tmp_path / "mapping.json"
    comprehend_tar = tmp_path / "output.tar.gz"

    _make_sanctions_csv(sanctions_csv)
    _make_mapping_json(mapping_json)
    _make_comprehend_tar(comprehend_tar)

    payload = run_pipeline_files(
        sanctions_csv_path=str(sanctions_csv),
        mapping_json_path=str(mapping_json),
        comprehend_tar_gz_path=str(comprehend_tar),
        ignore_words="is,as,the",  # prevent false positives from IS/AS as normal words
        acronym_max_len=3,
        return_all_sentences=True,
    )

    assert "results" in payload and "meta" in payload
    assert payload["meta"]["sentencesTotal"] == 3
    assert payload["meta"]["comprehendEntitiesTotal"] == 3  # filtered to PERSON/ORG only
    assert payload["meta"]["sentencesWithComprehendEntities"] == 2

    # Find g1
    g1 = next(r for r in payload["results"] if r["globalId"] == "g1")
    # CSV sentence match should sanction Exxon, Inc
    assert any(e["sanctionFlag"] and "Exxon" in e["text"] for e in g1["entities"])

    # g2 should NOT get sanction hits from IS/AS/IS-Y (ignore + boundary protections)
    g2 = next(r for r in payload["results"] if r["globalId"] == "g2")
    assert all(not e["sanctionFlag"] for e in g2["entities"])

    # g3 should include normalizedText for messy casing
    g3 = next(r for r in payload["results"] if r["globalId"] == "g3")
    person = next(e for e in g3["entities"] if e.get("type") == "PERSON")
    assert person["text"] == "joHN ArKI"
    assert person["normalizedText"] == "John Arki"
