import json
import tarfile
from pathlib import Path

from pipeline import run_pipeline_files


def _tar_with_entities(path: Path, lines):
    tmp_dir = path.parent / "tmp_tar_fp"
    tmp_dir.mkdir(parents=True, exist_ok=True)
    (tmp_dir / "manifest.json").write_text(json.dumps({"x": 1}), encoding="utf-8")
    (tmp_dir / "part-00000").write_text("\n".join(lines) + "\n", encoding="utf-8")
    with tarfile.open(path, "w:gz") as tf:
        tf.add(tmp_dir / "manifest.json", arcname="manifest.json")
        tf.add(tmp_dir / "part-00000", arcname="part-00000")


def test_short_acronyms_do_not_match_normal_words(tmp_path: Path):
    # Sanctions include IS/AS as acronyms and IS-Y. Sentence contains 'is yellow' and 'as red'.
    sanctions_csv = tmp_path / "sanctions.csv"
    sanctions_csv.write_text("id,sanction_list\n1,IS;AS;IS-Y\n", encoding="utf-8")

    mapping_json = tmp_path / "mapping.json"
    mapping = [{"globalId": "g1", "line": 1, "content": "this is yellow and as red"}]
    mapping_json.write_text(json.dumps(mapping), encoding="utf-8")

    comprehend_tar = tmp_path / "output.tar.gz"
    _tar_with_entities(comprehend_tar, [
        json.dumps({"Line": 1, "Entities": [
            {"BeginOffset": 5, "EndOffset": 7, "Score": 0.9, "Text": "is", "Type": "ORGANIZATION"},
            {"BeginOffset": 18, "EndOffset": 20, "Score": 0.9, "Text": "as", "Type": "ORGANIZATION"},
        ]})
    ])

    payload = run_pipeline_files(
        sanctions_csv_path=str(sanctions_csv),
        mapping_json_path=str(mapping_json),
        comprehend_tar_gz_path=str(comprehend_tar),
        ignore_words="is,as,the",
        acronym_max_len=3,
        return_all_sentences=True,
    )

    g1 = payload["results"][0]
    # No CSV sanctions should fire for normal words due to ignore list + acronym handling.
    assert all(not e["sanctionFlag"] for e in g1["entities"])
