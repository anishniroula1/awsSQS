"""pipeline.py

End-to-end pipeline orchestration using local file paths.

Inputs
------
- sanctions CSV
- mapping JSON list with keys: globalId, line, content
- Comprehend output.tar.gz containing JSONL with keys: Line, Entities

Output
------
A payload dict:
  {"results": [...], "meta": {...}}

Each result item:
  {"globalId": "...", "content": "...", "entities": [...]}

Each entity includes:
- text
- normalizedText
- beginOffset, endOffset
- sources
- sanctionFlag
- sanctionEntity (only when sanctioned)
- type, score (Comprehend only; only PERSON/ORGANIZATION are included from Comprehend)
"""

from __future__ import annotations

import json
import logging
import time
from typing import Any, Dict, List, Optional, Set

from comprehend_parse import parse_jsonl_records, read_jsonl_file
from comprehend_tar import extract_and_select_jsonl
from exact_match import find_sanctions_in_sentence
from mapping_parse import parse_mapping
from merge_entities import merge_for_sentence
from sanctions_csv import load_and_index_sanctions
from text_norm import normalize_with_map


def _norm(text: str) -> str:
    """Normalize a string to the same form used for sanctions matching and lookups."""
    n, _ = normalize_with_map(text or "")
    return n


def run_pipeline_files(
    *,
    sanctions_csv_path: str,
    mapping_json_path: str,
    comprehend_tar_gz_path: str,
    sanctions_column: Optional[str] = None,
    ignore_words: Optional[str] = None,
    acronym_max_len: int = 3,
    max_candidates: int = 50_000,
    return_all_sentences: bool = False,
    comprehend_tar_member: Optional[str] = None,
    logger: Optional[logging.Logger] = None,
) -> Dict[str, Any]:
    """Run the full pipeline using local files and return results + meta."""
    log = logger or logging.getLogger(__name__)
    t0 = time.time()

    # ---- Mapping (line -> globalId, globalId -> sentence text) ----
    mapping_list = json.load(open(mapping_json_path, "r", encoding="utf-8"))
    line_to_gid, gid_to_content, mapping_stats = parse_mapping(mapping_list)
    log.info("Mapping loaded: %s", mapping_stats)

    # ---- Comprehend JSONL extraction + parsing ----
    jsonl_path = extract_and_select_jsonl(
        comprehend_tar_gz_path,
        extract_dir="/tmp/comprehend_extract",
        preferred_member=comprehend_tar_member,
        logger=log,
    )
    records = read_jsonl_file(jsonl_path)
    comp_lines, comp_meta = parse_jsonl_records(records)
    log.info("Comprehend parsed: %s", comp_meta)

    # ---- Join Comprehend lineNumber -> globalId ----
    comp_by_gid: Dict[str, List[Dict[str, Any]]] = {}
    lines_matched = 0
    for line in comp_lines:
        ln = line.get("lineNumber")
        if ln is None:
            continue
        gid = line_to_gid.get(int(ln))
        if not gid:
            continue
        lines_matched += 1
        comp_by_gid.setdefault(gid, []).extend(line.get("entities") or [])

    # ---- Sanctions index ----
    phrases, anchor_index = load_and_index_sanctions(
        sanctions_csv_path,
        column_name=sanctions_column,
        ignore_words=ignore_words,
        acronym_max_len=acronym_max_len,
        logger=log,
    )
    sanctions_norm_set: Set[str] = set(_norm(p["raw"]) for p in phrases if p.get("raw"))

    # ---- CSV sentence matching ----
    csv_hits_by_gid: Dict[str, List[Dict[str, Any]]] = {}
    csv_total = 0
    for gid, content in gid_to_content.items():
        hits = find_sanctions_in_sentence(content, phrases, anchor_index, max_candidates=max_candidates)
        if hits:
            csv_hits_by_gid[gid] = hits
            csv_total += len(hits)

    # ---- Merge + dedupe ----
    results = []
    total_entities = 0
    sanctioned_entities = 0

    for gid, content in gid_to_content.items():
        merged = merge_for_sentence(
            sentence_text=content,
            csv_hits=csv_hits_by_gid.get(gid, []),
            comprehend_ents=comp_by_gid.get(gid, []),
            sanctions_norm_set=sanctions_norm_set,
        )

        if merged or return_all_sentences:
            total_entities += len(merged)
            sanctioned_entities += sum(1 for e in merged if e.get("sanctionFlag"))
            results.append({"globalId": gid, "content": content, "entities": merged})

    meta = {
        **mapping_stats,
        "sentencesTotal": len(gid_to_content),
        "sanctionsLoaded": len(phrases),
        "anchors": len(anchor_index),
        "csvMatchTotal": csv_total,
        "sentencesWithCsvHits": len(csv_hits_by_gid),
        "comprehendRecords": comp_meta["records"],
        "comprehendEntitiesTotal": comp_meta["entitiesTotal"],
        "comprehendRecordsWithLine": comp_meta["recordsWithLine"],
        "comprehendLinesMatchedToMapping": lines_matched,
        "sentencesWithComprehendEntities": len(comp_by_gid),
        "sentencesInResults": len(results),
        "totalEntitiesInResults": total_entities,
        "sanctionedEntities": sanctioned_entities,
        "maxCandidates": max_candidates,
        "ignoreWords": ignore_words or "",
        "acronymMaxLen": acronym_max_len,
        "returnAllSentences": return_all_sentences,
        "tookMs": int((time.time() - t0) * 1000),
        "selectedJsonlPath": jsonl_path,
    }

    return {"results": results, "meta": meta}
