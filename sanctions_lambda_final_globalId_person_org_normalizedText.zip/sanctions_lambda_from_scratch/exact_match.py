"""exact_match.py

Exact matching of sanctions phrases against sentence text, with offsets.

Output shape
------------
A list of matches, each like:
  {
    "entity": "<raw sanctions entity>",
    "beginOffset": <int>,  # in original sentence
    "endOffset": <int>,    # exclusive end
    "matchedText": "<substring from sentence>"
  }

Matching modes
--------------
1) **Acronym mode (case-sensitive)**:
   Short ALL-CAPS items (like "IS") are matched case-sensitively in the original sentence
   using alphanumeric boundaries. This prevents false positives with normal English.

2) **Normalized mode (case-insensitive)**:
   Most entities are matched on normalized strings (lowercase, punctuation removed).
   Matches are only accepted when the normalized match is **word-bounded**
   to prevent prefix matches like:
   - sanctions: "IS-Y" -> normalized "is y"
   - sentence:  "is yellow" -> normalized "is yellow"
   In this case we reject because "is y" is not word-bounded on the right side.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Set

from text_norm import normalize_with_map, tokens


def _find_case_sensitive_hits(sentence: str, raw: str):
    """
    Yield (begin, end) offsets for case-sensitive matches of ``raw`` with alnum boundaries.

    Why boundaries?
    - If raw is "IS" we want to match "IS" as a token, not inside "ISLAND".
    """
    pat = re.compile(rf"(?<![A-Za-z0-9]){re.escape(raw)}(?![A-Za-z0-9])")
    for m in pat.finditer(sentence):
        yield m.start(), m.end()


def find_sanctions_in_sentence(
    sentence: str,
    phrases: List[Dict[str, Any]],
    anchor_index: Dict[str, List[int]],
    *,
    max_candidates: int = 50_000,
) -> List[Dict[str, Any]]:
    """
    Find exact sanctions matches in a sentence, returning begin/end offsets.

    Parameters
    ----------
    sentence:
        The sentence text to scan.
    phrases:
        Phrase list returned by `load_and_index_sanctions`.
    anchor_index:
        Token -> phrase_id list mapping returned by `load_and_index_sanctions`.
    max_candidates:
        Safety cap on number of candidate phrases evaluated for this sentence.

        Why this exists:
        - Some sentences contain extremely common words ("group", "bank", ...).
        - If an anchor token is common, candidate sets can explode.
        - Lambda needs predictable runtime. This cap prevents worst-case blowups.

    Returns
    -------
    list[dict]
        A list of match dicts.
    """
    norm_sentence, norm_map = normalize_with_map(sentence)
    if not norm_sentence:
        return []

    # Tokenize sentence in normalized space for candidate selection.
    sent_toks = set(tokens(norm_sentence))
    if not sent_toks:
        return []

    # Candidate selection: collect phrase ids for any anchor token in the sentence.
    cand_ids: Set[int] = set()
    for t in sent_toks:
        ids = anchor_index.get(t)
        if ids:
            cand_ids.update(ids)
            # Hard cap to protect Lambda runtime.
            if len(cand_ids) >= max_candidates:
                break

    if not cand_ids:
        return []

    out: List[Dict[str, Any]] = []

    for pid in cand_ids:
        p = phrases[pid]

        # ---- Case-sensitive acronym matching ----
        if p["case_sensitive"]:
            for b, e in _find_case_sensitive_hits(sentence, p["raw"]):
                out.append({"entity": p["raw"], "beginOffset": b, "endOffset": e, "matchedText": sentence[b:e]})
            continue

        # ---- Normalized matching ----
        phrase_norm = p["norm"]
        start = 0
        while True:
            pos = norm_sentence.find(phrase_norm, start)
            if pos == -1:
                break

            end = pos + len(phrase_norm)

            # Enforce word boundaries in normalized space.
            # This prevents prefix matches ("is y" in "is yellow").
            left_ok = (pos == 0) or (norm_sentence[pos - 1] == " ")
            right_ok = (end == len(norm_sentence)) or (norm_sentence[end] == " ")
            if not (left_ok and right_ok):
                start = pos + 1
                continue

            # Map normalized offsets back to original offsets.
            if end > len(norm_map):
                break
            orig_start = norm_map[pos]
            orig_end = norm_map[end - 1] + 1  # inclusive -> exclusive

            out.append({
                "entity": p["raw"],
                "beginOffset": orig_start,
                "endOffset": orig_end,
                "matchedText": sentence[orig_start:orig_end],
            })

            # Continue searching for another occurrence.
            start = pos + 1

    # Stable order for debugging and deterministic outputs.
    out.sort(key=lambda r: (r["beginOffset"], -(r["endOffset"] - r["beginOffset"])))
    return out
