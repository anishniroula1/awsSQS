"""comprehend_parse.py

Parse Comprehend JSONL records into a normalized per-line structure.

Comprehend JSONL shapes vary depending on job type and wrappers. In practice you may see:
- Records that contain `Entities` directly
- Records that contain `Result -> Entities`
- Records that contain `Output -> Entities`
- Records with line numbers under keys like `Line`, `LineNumber`, etc.
- Records without line keys at all (then we rely on their file order)

This parser is defensive:
- it searches for entities in common wrapper keys
- it uses explicit line numbers when present
- it normalizes entity fields to a consistent schema
"""

from __future__ import annotations

import json
from typing import Any, Dict, List, Optional, Tuple

LINE_KEYS = ("Line", "line", "LineNumber", "lineNumber", "LineNo", "lineNo", "linenumber")
ENT_KEYS = ("Entities", "entities", "EntityList", "entityList")


def _find_entities(obj: Any) -> Optional[List[Dict[str, Any]]]:
    """
    Recursively attempt to find the entities list in a JSON object.

    Returns
    -------
    list[dict] | None
        - list of entity dicts if found
        - None if not found
    """
    if obj is None:
        return None

    if isinstance(obj, list):
        # Sometimes a record might itself be the entity list.
        if all(isinstance(x, dict) for x in obj):
            return obj
        return None

    if not isinstance(obj, dict):
        return None

    # Direct keys
    for k in ENT_KEYS:
        v = obj.get(k)
        if isinstance(v, list):
            return v

    # Common wrapper keys
    for k in ("Result", "result", "Response", "response", "Output", "output"):
        if k in obj:
            found = _find_entities(obj[k])
            if found is not None:
                return found

    return None


def _extract_line_number(obj: Any, fallback: int) -> int:
    """
    Try to extract a line number from a record; fall back to sequential order.

    Why?
    - Mapping JSON uses a line number (Line) that must align with Comprehend output.
    - If Comprehend gives us the line number explicitly, we should respect it.
    """
    if isinstance(obj, dict):
        for k in LINE_KEYS:
            if k in obj:
                try:
                    return int(obj[k])
                except Exception:
                    pass

        # Some outputs put line info into a nested Location object.
        loc = obj.get("Location") or obj.get("location")
        if isinstance(loc, dict):
            for k in LINE_KEYS:
                if k in loc:
                    try:
                        return int(loc[k])
                    except Exception:
                        pass

    return fallback


def read_jsonl_file(path: str) -> List[Any]:
    """
    Read a JSONL file (one JSON object per line) into a list of Python objects.

    Parameters
    ----------
    path:
        Path to a JSONL file.

    Returns
    -------
    list[Any]
        Parsed JSON objects for each non-empty line.
    """
    out: List[Any] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            out.append(json.loads(line))
    return out


def parse_jsonl_records(records: List[Any]) -> Tuple[List[Dict[str, Any]], Dict[str, int]]:
    """
    Convert raw JSONL records into per-line normalized entities.

    Parameters
    ----------
    records:
        List of JSON objects read from the JSONL file.

    Returns
    -------
    (lines, meta):
        lines:
            [{"lineNumber": int, "entities": [ ... ]}, ...]
        meta:
            counts useful for debugging (records, entitiesTotal, recordsWithExplicitLine)
    """
    lines: List[Dict[str, Any]] = []
    total_entities = 0
    with_explicit_line = 0

    for i, obj in enumerate(records, start=1):
        ln = _extract_line_number(obj, i)

        if isinstance(obj, dict) and any(k in obj for k in LINE_KEYS):
            with_explicit_line += 1

        ents = _find_entities(obj) or []
        norm_ents = []

        for e in ents:
            if not isinstance(e, dict):
                continue

            # Normalize keys so downstream logic doesn't care about casing differences.
            norm_ents.append({
                "Text": e.get("Text") or e.get("text"),
                "BeginOffset": e.get("BeginOffset") if e.get("BeginOffset") is not None else e.get("beginOffset"),
                "EndOffset": e.get("EndOffset") if e.get("EndOffset") is not None else e.get("endOffset"),
                "Type": e.get("Type") or e.get("type"),
                "Score": e.get("Score") if e.get("Score") is not None else e.get("score"),
            })

        total_entities += len(norm_ents)
        lines.append({"lineNumber": ln, "entities": norm_ents})

    meta = {"records": len(records), "entitiesTotal": total_entities, "recordsWithExplicitLine": with_explicit_line}
    return lines, meta
