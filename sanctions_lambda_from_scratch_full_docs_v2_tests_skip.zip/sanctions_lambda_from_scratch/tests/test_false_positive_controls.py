import csv
from sanctions_csv import load_and_index_sanctions
from exact_match import find_sanctions_in_sentence

def test_is_y_does_not_match_is_yellow(tmp_path):
    p = tmp_path / "s.csv"
    with p.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["sanction_list"])
        w.writeheader()
        w.writerow({"sanction_list": "IS-Y"})
    phrases, idx = load_and_index_sanctions(str(p), column_name="sanction_list")
    assert find_sanctions_in_sentence("this is yellow", phrases, idx) == []

def test_short_all_caps_is_matches_only_uppercase(tmp_path):
    p = tmp_path / "s.csv"
    with p.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["sanction_list"])
        w.writeheader()
        w.writerow({"sanction_list": "IS"})
    phrases, idx = load_and_index_sanctions(str(p), column_name="sanction_list", acronym_max_len=3)
    assert find_sanctions_in_sentence("this is yellow", phrases, idx) == []
    hits = find_sanctions_in_sentence("this IS yellow", phrases, idx)
    assert len(hits) == 1
    assert hits[0]["matchedText"] == "IS"

def test_ignore_words_skips_generic_single_token(tmp_path):
    p = tmp_path / "s.csv"
    with p.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["sanction_list"])
        w.writeheader()
        w.writerow({"sanction_list": "john;is;as"})
    phrases, idx = load_and_index_sanctions(str(p), column_name="sanction_list", ignore_words="is,as")
    assert find_sanctions_in_sentence("this is fine", phrases, idx) == []
    assert len(find_sanctions_in_sentence("met john today", phrases, idx)) == 1
