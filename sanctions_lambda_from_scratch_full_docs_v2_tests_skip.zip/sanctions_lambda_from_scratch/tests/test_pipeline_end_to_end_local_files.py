import json
import csv
import tarfile
from pathlib import Path
from pipeline import run_pipeline_files

def _make_tar(tmp_path: Path, member_name: str, member_text: str) -> str:
    member = tmp_path / "m"
    member.write_text(member_text, encoding="utf-8")
    tar_path = tmp_path / "output.tar.gz"
    with tarfile.open(tar_path, "w:gz") as tf:
        man = tmp_path / "manifest.json"
        man.write_text(json.dumps({"job": "comprehend"}), encoding="utf-8")
        tf.add(man, arcname="manifest.json")
        tf.add(member, arcname=member_name)
    return str(tar_path)

def test_pipeline_smoke(tmp_path):
    sanctions = tmp_path / "sanctions.csv"
    with sanctions.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["sanction_list"])
        w.writeheader()
        w.writerow({"sanction_list": "Exxon, Inc;Jon Julu;IS-Y;IS"})

    mapping = [
        {"Line": 1, "content": "this is yellow", "sentence_id": "s1"},
        {"Line": 2, "content": "I met Jon Julu yesterday.", "sentence_id": "s2"},
        {"Line": 3, "content": "EXXON INC reported earnings.", "sentence_id": "s3"},
        {"Line": 4, "content": "this IS yellow", "sentence_id": "s4"},
    ]
    mapping_path = tmp_path / "mapping.json"
    mapping_path.write_text(json.dumps(mapping), encoding="utf-8")

    jsonl = (
        json.dumps({"Line": 1, "Entities": [{"Text": "yellow", "BeginOffset": 8, "EndOffset": 14, "Type": "OTHER"}]}) + "\n" +
        json.dumps({"Line": 2, "Entities": [{"Text": "Jon Julu", "BeginOffset": 6, "EndOffset": 13, "Type": "PERSON"}]}) + "\n" +
        json.dumps({"Line": 3, "Entities": [{"Text": "EXXON INC", "BeginOffset": 0, "EndOffset": 9, "Type": "ORGANIZATION"}]}) + "\n" +
        json.dumps({"Line": 4, "Entities": [{"Text": "IS", "BeginOffset": 5, "EndOffset": 7, "Type": "OTHER"}]}) + "\n"
    )
    tar = _make_tar(tmp_path, "part-00000", jsonl)

    payload = run_pipeline_files(
        sanctions_csv_path=str(sanctions),
        mapping_json_path=str(mapping_path),
        comprehend_tar_gz_path=tar,
        ignore_words="is,as",
        acronym_max_len=3,
        return_all_sentences=True,
    )

    assert payload["meta"]["sentencesTotal"] == 4
    by_id = {r["sentence_id"]: r for r in payload["results"]}
    assert any(e.get("sanctionFlag") for e in by_id["s2"]["entities"])
    assert any(e.get("sanctionFlag") for e in by_id["s3"]["entities"])
