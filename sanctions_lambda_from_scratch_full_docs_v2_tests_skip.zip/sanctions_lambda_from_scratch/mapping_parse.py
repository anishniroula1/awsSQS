"""mapping_parse.py

Parse your mapping JSON format used to connect Comprehend line numbers to sentence IDs.

Expected input
--------------
A JSON array (list) of objects like:
  {
    "Line": 1,
    "content": "actual sentence text",
    "sentence_id": "abc123"
  }

Outputs
-------
1) ``line_to_sid``: dict[int -> sentence_id]
2) ``sid_to_content``: dict[sentence_id -> sentence text]

We also return stats so you can validate the mapping quickly in logs.
"""

from __future__ import annotations

from typing import Any, Dict, Tuple


def parse_mapping(mapping_obj: Any) -> Tuple[Dict[int, str], Dict[str, str], Dict[str, int]]:
    """
    Parse mapping JSON and return lookup structures + stats.

    Parameters
    ----------
    mapping_obj:
        Either:
        - a list of mapping dicts
        - or a wrapper dict containing the list under keys like "items"/"data"

    Returns
    -------
    (line_to_sid, sid_to_content, stats)
        line_to_sid:
            Maps integer line numbers -> sentence_id
        sid_to_content:
            Maps sentence_id -> original sentence text
        stats:
            Counts and min/max line numbers for sanity checks
    """
    # Some callers wrap the array under a key (defensive support).
    if isinstance(mapping_obj, dict):
        for k in ("items", "mappings", "data"):
            if k in mapping_obj and isinstance(mapping_obj[k], list):
                mapping_obj = mapping_obj[k]
                break

    if not isinstance(mapping_obj, list):
        raise ValueError("Mapping JSON must be a list")

    line_to_sid: Dict[int, str] = {}
    sid_to_content: Dict[str, str] = {}
    min_line = None
    max_line = None
    loaded = 0

    for it in mapping_obj:
        if not isinstance(it, dict):
            continue

        # Accept both `Line` and `line` for flexibility.
        line = it.get("Line") if it.get("Line") is not None else it.get("line")

        # Accept multiple common ID keys.
        sid = it.get("sentence_id") or it.get("sentenceId") or it.get("id")

        content = it.get("content")
        if line is None or sid is None or content is None:
            continue

        try:
            ln = int(line)
        except Exception:
            continue

        sid_s = str(sid)
        line_to_sid[ln] = sid_s
        sid_to_content[sid_s] = str(content)

        loaded += 1
        min_line = ln if min_line is None else min(min_line, ln)
        max_line = ln if max_line is None else max(max_line, ln)

    stats = {
        "mappingItems": len(mapping_obj),
        "mappingLoaded": loaded,
        "mappingMinLine": min_line or 0,
        "mappingMaxLine": max_line or 0,
    }
    return line_to_sid, sid_to_content, stats
