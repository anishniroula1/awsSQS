"""s3_utils.py

S3 read/write helpers used by the Lambda handler.

Design goals
------------
1) **Testability**: We create the boto3 client lazily inside each function.
   This is important for tests that use `moto`, because moto patches boto3 at runtime.
2) **Simplicity**: We only implement what the pipeline needs:
   - download an object to /tmp
   - upload a JSON payload back to S3

Lambda note
-----------
The Lambda filesystem is mostly read-only, but **/tmp is writable**. That is why
we download artifacts there.
"""

from __future__ import annotations

import json
import logging
from typing import Any, Optional

try:
    import boto3  # type: ignore
except Exception:  # pragma: no cover
    boto3 = None  # type: ignore


def _client():
    """
    Create and return a new boto3 S3 client.

    This function is private because callers should not need to manage clients.
    Keeping it private also makes it easy to swap in alternative implementations later.
    """
    if boto3 is None:  # pragma: no cover
        raise RuntimeError("boto3 not available; S3 access requires boto3")
    return boto3.client("s3")


def download_to_tmp(bucket: str, key: str, filename: str, logger: Optional[logging.Logger] = None) -> str:
    """
    Download ``s3://<bucket>/<key>`` to ``/tmp/<filename>`` and return the local path.

    Parameters
    ----------
    bucket, key:
        S3 location.
    filename:
        Local filename (no directories). Written under /tmp.
    logger:
        Optional logger for consistent logs.

    Returns
    -------
    str
        Absolute local path where the object was saved.
    """
    log = logger or logging.getLogger(__name__)
    path = f"/tmp/{filename}"

    # Log the exact S3 path and destination path to make debugging trivial.
    log.info("Downloading s3://%s/%s -> %s", bucket, key, path)

    _client().download_file(bucket, key, path)
    return path


def upload_json(bucket: str, key: str, payload: Any, logger: Optional[logging.Logger] = None) -> None:
    """
    Upload a Python object as JSON to ``s3://<bucket>/<key>``.

    Parameters
    ----------
    bucket, key:
        S3 destination.
    payload:
        Any JSON-serializable Python object (dict/list/...).
    logger:
        Optional logger.

    Notes
    -----
    - We always encode JSON as UTF-8 and set ``ContentType=application/json``.
    """
    log = logger or logging.getLogger(__name__)
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    log.info("Uploading JSON to s3://%s/%s (%d bytes)", bucket, key, len(body))

    _client().put_object(Bucket=bucket, Key=key, Body=body, ContentType="application/json")
