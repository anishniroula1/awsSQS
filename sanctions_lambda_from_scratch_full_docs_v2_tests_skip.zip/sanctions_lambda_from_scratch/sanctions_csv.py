"""sanctions_csv.py

Load sanctions entities from a CSV and build an anchor-token index for fast matching.

Input format
------------
- CSV has a header row.
- One column (often called something like ``sanction_list``) contains a list of entities.
- Each row may contain multiple entities separated by semicolons:
  "Exxon, Inc;Limited Group;Jon Julu"

Scale constraints
-----------------
You might have:
- ~17k CSV rows
- up to ~100k total entities (because each row contains 10–20 entities)

A naive approach (check every entity against every sentence) is too slow for Lambda.
So we build a **phrase index**.

Anchor-token indexing
---------------------
For each entity phrase we:
1) Normalize and tokenize it.
2) Choose an anchor token (the rarest token in that phrase across the whole list).
3) Store the phrase id under that anchor token.

For each sentence we:
1) Tokenize the normalized sentence.
2) Collect candidate phrase ids whose anchor appears in the sentence.
3) Only evaluate those candidates for exact matches.

This reduces comparisons dramatically.

False-positive controls
----------------------
- Short ALL-CAPS tokens like "IS" / "AS" are treated as *case-sensitive acronyms*.
  This prevents matching normal English "is" / "as".
- You can supply ``IGNORE_WORDS`` to drop generic single-token entities such as
  "is", "as", "the".
"""

from __future__ import annotations

import csv
import logging
import re
from collections import Counter, defaultdict
from typing import Any, Dict, List, Optional, Set, Tuple

from text_norm import normalize_with_map, tokens


def _looks_like_all_caps_acronym(raw: str, max_len: int) -> bool:
    """
    Return True if ``raw`` looks like a short ALL-CAPS acronym.

    Why we need this:
    - Sanctions lists sometimes contain abbreviations like "IS" or "AS".
    - If we match case-insensitively, those would match normal English "is" / "as",
      producing a lot of false positives.

    Heuristic
    ---------
    - Extract alphanumeric characters, require alphabetic
    - Length must be <= ``max_len``
    - Letters must be all uppercase

    Parameters
    ----------
    raw:
        Original entity string from CSV.
    max_len:
        Upper bound for acronym length (default is 3 in the pipeline).

    Returns
    -------
    bool
        True if we should treat this as a case-sensitive acronym.
    """
    s = (raw or "").strip()
    if not s:
        return False

    # Strip punctuation for length checks ("I.S." -> "IS").
    alnum = re.sub(r"[^A-Za-z0-9]", "", s)
    if not alnum.isalpha():
        return False

    if len(alnum) > max_len:
        return False

    # Must contain letters and they must be ALL CAPS.
    letters = re.sub(r"[^A-Za-z]", "", s)
    return bool(letters) and letters.upper() == letters


def _parse_ignore_words(ignore_words: Optional[str]) -> Set[str]:
    """
    Parse IGNORE_WORDS into a set of normalized tokens.

    Accepted separators:
    - comma
    - semicolon
    - whitespace/newlines

    Example
    -------
    IGNORE_WORDS = "is,as,the" -> {"is", "as", "the"}
    """
    if not ignore_words:
        return set()

    parts = re.split(r"[;,\s]+", ignore_words.strip())
    out: Set[str] = set()
    for p in parts:
        p = p.strip()
        if not p:
            continue

        # Normalize ignore words so they compare correctly with our tokenization.
        norm, _ = normalize_with_map(p)
        out.update(tokens(norm))

    return out


def _autodetect_sanctions_column(fieldnames: List[str]) -> str:
    """
    Best-effort detection of the sanctions column name.

    Strategy
    --------
    1) Pick the first column whose name contains "sanction" (case-insensitive).
    2) Otherwise try common names (sanction_list, sanctions, sanction list, sanction).
    3) If still not found, raise with a helpful error listing the columns.

    This is private because callers normally either pass SANCTIONS_COLUMN or rely on detection.
    """
    for c in fieldnames:
        if "sanction" in c.lower():
            return c

    lowered = {c.lower(): c for c in fieldnames}
    for candidate in ("sanction_list", "sanctions", "sanction list", "sanction"):
        if candidate in lowered:
            return lowered[candidate]

    raise ValueError(f"Could not auto-detect sanctions column. Columns: {fieldnames}")


def load_and_index_sanctions(
    csv_path: str,
    *,
    column_name: Optional[str] = None,
    ignore_words: Optional[str] = None,
    acronym_max_len: int = 3,
    logger: Optional[logging.Logger] = None,
) -> Tuple[List[Dict[str, Any]], Dict[str, List[int]]]:
    """
    Load sanctions entities from a CSV and build an anchor-token index.

    Parameters
    ----------
    csv_path:
        Local path to the CSV file.
    column_name:
        Name of the sanctions column. If not provided, auto-detect via `_autodetect_sanctions_column`.
    ignore_words:
        Optional string list of words to ignore (see `_parse_ignore_words`).
    acronym_max_len:
        ALL-CAPS phrases <= this length are treated as case-sensitive acronyms.
    logger:
        Optional logger.

    Returns
    -------
    (phrases, anchor_index):
        phrases:
            List of dicts:
              - raw: original phrase
              - norm: normalized phrase
              - toks: tokens tuple (for indexing)
              - case_sensitive: bool (True for acronyms like IS/AS)
        anchor_index:
            Dict mapping anchor token -> list of phrase indexes.

    Important behavior notes
    ------------------------
    - We de-duplicate using the normalized phrase (`norm`) because the same phrase
      can appear multiple times across rows.
    - We choose the anchor token as the *rarest token* in that phrase across the dataset.
      This keeps candidate sets small and makes runtime more predictable.
    """
    log = logger or logging.getLogger(__name__)
    ignore_set = _parse_ignore_words(ignore_words)

    phrases: List[Dict[str, Any]] = []
    seen_norm: Set[str] = set()  # used to dedupe phrases after normalization
    df = Counter()               # document frequency of tokens across all phrases

    with open(csv_path, "r", newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames:
            raise ValueError("CSV has no header")

        col = column_name or _autodetect_sanctions_column(reader.fieldnames)
        if col not in reader.fieldnames:
            raise ValueError(f"Sanctions column '{col}' not found. Columns: {reader.fieldnames}")

        rows = 0
        raw_entities = 0

        for row in reader:
            rows += 1
            cell = (row.get(col) or "").strip()
            if not cell:
                continue

            # Each cell may contain multiple entity strings separated by semicolons.
            for part in cell.split(";"):
                raw_entities += 1
                raw = part.strip()
                if not raw:
                    continue

                # Determine if this entity is likely a short acronym like "IS" or "AS".
                case_sensitive = _looks_like_all_caps_acronym(raw, acronym_max_len)

                # Normalize for dedupe and for case-insensitive matching.
                norm, _ = normalize_with_map(raw)
                if not norm or norm in seen_norm:
                    continue

                toks = tuple(tokens(norm))
                if not toks:
                    continue

                # Ignore generic words only when the entity is NOT an acronym.
                # This preserves acronyms like "IS" if you actually want them.
                if len(toks) == 1 and toks[0] in ignore_set and not case_sensitive:
                    continue

                phrases.append({"raw": raw, "norm": norm, "toks": toks, "case_sensitive": case_sensitive})
                seen_norm.add(norm)

                # Update DF using unique tokens per phrase (not token frequency inside phrase).
                df.update(set(toks))

    # Build anchor index: token -> phrase ids
    anchor_index: Dict[str, List[int]] = defaultdict(list)
    for i, p in enumerate(phrases):
        # Choose the rarest token as anchor to minimize candidate explosions.
        anchor = min(set(p["toks"]), key=lambda t: df.get(t, 10**9))
        anchor_index[anchor].append(i)

    log.info(
        "Loaded sanctions: unique=%d anchors=%d ignoreTokens=%d column=%s",
        len(phrases), len(anchor_index), len(ignore_set), col
    )

    return phrases, dict(anchor_index)
