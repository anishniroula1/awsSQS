"""pipeline.py

End-to-end pipeline orchestration using local file paths.

The Lambda handler:
1) downloads artifacts to /tmp
2) calls this module to run the pipeline
3) optionally uploads the final JSON

The function `run_pipeline_files` returns:
- results: per-sentence merged entities with sanctionFlag
- meta: detailed counters for easy debugging ("why is results empty?")

This module intentionally emits many meta counters; they are your first stop when
diagnosing empty results or join mismatches.
"""

from __future__ import annotations

import json
import logging
import time
from typing import Any, Dict, List, Optional, Set

from comprehend_parse import parse_jsonl_records, read_jsonl_file
from comprehend_tar import extract_and_select_jsonl
from exact_match import find_sanctions_in_sentence
from mapping_parse import parse_mapping
from merge_entities import merge_for_sentence
from sanctions_csv import load_and_index_sanctions
from text_norm import normalize_with_map


def _norm(text: str) -> str:
    """Normalize a string to the same form used for sanctions matching."""
    n, _ = normalize_with_map(text or "")
    return n


def run_pipeline_files(
    *,
    sanctions_csv_path: str,
    mapping_json_path: str,
    comprehend_tar_gz_path: str,
    sanctions_column: Optional[str] = None,
    ignore_words: Optional[str] = None,
    acronym_max_len: int = 3,
    max_candidates: int = 50_000,
    return_all_sentences: bool = False,
    comprehend_tar_member: Optional[str] = None,
    logger: Optional[logging.Logger] = None,
) -> Dict[str, Any]:
    """
    Run the full pipeline using local files.

    Parameters
    ----------
    sanctions_csv_path:
        Local path to sanctions CSV downloaded from S3.
    mapping_json_path:
        Local path to mapping JSON downloaded from S3.
    comprehend_tar_gz_path:
        Local path to Comprehend output.tar.gz downloaded from S3.
    sanctions_column:
        Optional override for the sanctions column name. If None, auto-detect.
    ignore_words:
        Optional ignore words list for dropping generic single-token entities.
    acronym_max_len:
        Max length for ALL-CAPS items to treat as case-sensitive acronyms.
    max_candidates:
        Safety cap for candidate phrases evaluated per sentence.
    return_all_sentences:
        If True, include sentences in the output even when they have 0 merged entities.
        Useful for debugging and for downstream systems that expect every sentence.
    comprehend_tar_member:
        Optional member name to force from the tar.gz (advanced debugging).
    logger:
        Optional logger.

    Returns
    -------
    dict
        {
          "results": [...],
          "meta": {...}
        }
    """
    log = logger or logging.getLogger(__name__)
    t0 = time.time()

    # ---- Load mapping JSON ----
    mapping_obj = json.load(open(mapping_json_path, "r", encoding="utf-8"))
    line_to_sid, sid_to_content, mapping_stats = parse_mapping(mapping_obj)
    log.info("Mapping loaded: %s", mapping_stats)

    # ---- Extract + parse Comprehend output ----
    jsonl_path = extract_and_select_jsonl(
        comprehend_tar_gz_path,
        extract_dir="/tmp/comprehend_extract",
        preferred_member=comprehend_tar_member,
        logger=log,
    )
    records = read_jsonl_file(jsonl_path)
    comp_lines, comp_meta = parse_jsonl_records(records)
    log.info("Comprehend parsed: %s", comp_meta)

    # ---- Join Comprehend records to sentences using line numbers ----
    comp_by_sid: Dict[str, List[Dict[str, Any]]] = {}
    lines_matched = 0

    for line in comp_lines:
        ln = line.get("lineNumber")
        if ln is None:
            continue

        # The mapping uses integer line numbers. Convert carefully.
        sid = line_to_sid.get(int(ln))
        if not sid:
            continue

        lines_matched += 1
        comp_by_sid.setdefault(sid, []).extend(line.get("entities") or [])

    # ---- Load sanctions + build index ----
    phrases, anchor_index = load_and_index_sanctions(
        sanctions_csv_path,
        column_name=sanctions_column,
        ignore_words=ignore_words,
        acronym_max_len=acronym_max_len,
        logger=log,
    )

    # Normalized sanctions set for fast exact lookup against Comprehend entity text.
    sanctions_norm_set: Set[str] = set(_norm(p["raw"]) for p in phrases if p.get("raw"))

    # ---- CSV exact match: sanctions -> sentence ----
    csv_hits_by_sid: Dict[str, List[Dict[str, Any]]] = {}
    csv_total = 0

    for sid, content in sid_to_content.items():
        hits = find_sanctions_in_sentence(content, phrases, anchor_index, max_candidates=max_candidates)
        if hits:
            csv_hits_by_sid[sid] = hits
            csv_total += len(hits)

    # ---- Merge + dedupe ----
    results = []
    total_entities = 0
    sanctioned_entities = 0

    for sid, content in sid_to_content.items():
        merged = merge_for_sentence(
            sentence_text=content,
            csv_hits=csv_hits_by_sid.get(sid, []),
            comprehend_ents=comp_by_sid.get(sid, []),
            sanctions_norm_set=sanctions_norm_set,
        )

        if merged or return_all_sentences:
            total_entities += len(merged)
            sanctioned_entities += sum(1 for e in merged if e.get("sanctionFlag"))
            results.append({"sentence_id": sid, "content": content, "entities": merged})

    meta = {
        **mapping_stats,
        "sentencesTotal": len(sid_to_content),
        "sanctionsLoaded": len(phrases),
        "anchors": len(anchor_index),
        "csvMatchTotal": csv_total,
        "sentencesWithCsvHits": len(csv_hits_by_sid),
        "comprehendRecords": comp_meta["records"],
        "comprehendEntitiesTotal": comp_meta["entitiesTotal"],
        "comprehendRecordsWithExplicitLine": comp_meta["recordsWithExplicitLine"],
        "comprehendLinesMatchedToMapping": lines_matched,
        "sentencesWithComprehendEntities": len(comp_by_sid),
        "sentencesInResults": len(results),
        "totalEntitiesInResults": total_entities,
        "sanctionedEntities": sanctioned_entities,
        "maxCandidates": max_candidates,
        "ignoreWords": ignore_words or "",
        "acronymMaxLen": acronym_max_len,
        "returnAllSentences": return_all_sentences,
        "tookMs": int((time.time() - t0) * 1000),
        "selectedJsonlPath": jsonl_path,
    }

    return {"results": results, "meta": meta}
