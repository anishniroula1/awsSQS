"""merge_entities.py

Merges CSV hits + Comprehend entities and dedupes per sentence.
"""

from __future__ import annotations
from typing import Any, Dict, List, Optional, Set, Tuple
from text_norm import normalize_with_map

def _norm(t: str) -> str:
    n, _ = normalize_with_map(t or "")
    return n

def _overlap(a0: int, a1: int, b0: int, b1: int) -> bool:
    return a0 < b1 and b0 < a1

def merge_for_sentence(
    sentence_text: str,
    csv_hits: List[Dict[str, Any]],
    comprehend_ents: List[Dict[str, Any]],
    sanctions_norm_set: Set[str],
) -> List[Dict[str, Any]]:
    merged: Dict[Tuple[int, int, str], Dict[str, Any]] = {}
    csv_spans = [(int(h["beginOffset"]), int(h["endOffset"]), h["entity"]) for h in csv_hits]

    def upsert(rec: Dict[str, Any]) -> None:
        key = (rec["beginOffset"], rec["endOffset"], _norm(rec["text"]))
        ex = merged.get(key)
        if not ex:
            merged[key] = rec
            return
        ex["sources"] = sorted(set(ex["sources"]) | set(rec["sources"]))
        ex["sanctionFlag"] = bool(ex.get("sanctionFlag") or rec.get("sanctionFlag"))
        if rec.get("sanctionEntity"):
            if not ex.get("sanctionEntity") or len(str(rec["sanctionEntity"])) > len(str(ex["sanctionEntity"])):
                ex["sanctionEntity"] = rec["sanctionEntity"]

    for h in csv_hits:
        b, e = int(h["beginOffset"]), int(h["endOffset"])
        upsert({
            "text": h.get("matchedText", sentence_text[b:e]),
            "beginOffset": b,
            "endOffset": e,
            "sources": ["csv_sentence_match"],
            "sanctionFlag": True,
            "sanctionEntity": h["entity"],
        })

    for e in comprehend_ents:
        text = e.get("Text") or ""
        try:
            b = int(e.get("BeginOffset"))
            en = int(e.get("EndOffset"))
        except Exception:
            continue
        if not text or b < 0 or en <= b:
            continue

        overlap_entity: Optional[str] = None
        for cb, ce, cname in csv_spans:
            if _overlap(b, en, cb, ce):
                overlap_entity = cname
                break

        sanction_flag = False
        sanction_entity = None
        if overlap_entity:
            sanction_flag = True
            sanction_entity = overlap_entity
        else:
            if _norm(text) in sanctions_norm_set:
                sanction_flag = True
                sanction_entity = text

        rec = {
            "text": text,
            "beginOffset": b,
            "endOffset": en,
            "sources": ["comprehend"],
            "sanctionFlag": sanction_flag,
            "type": e.get("Type"),
            "score": e.get("Score"),
        }
        if sanction_entity:
            rec["sanctionEntity"] = sanction_entity
        upsert(rec)

    out = list(merged.values())
    out.sort(key=lambda r: (r["beginOffset"], -(r["endOffset"] - r["beginOffset"])))
    return out
