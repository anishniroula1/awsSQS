"""sanctions_csv.py

Loads sanctions entities from CSV and builds an anchor token index for fast matching.

Why an index?
- You may have ~100k entities. Comparing every entity against every sentence is too slow.
- Anchor indexing reduces comparisons:
  For each phrase, choose a rare token as its anchor.
  For each sentence, only consider phrases whose anchor token appears in the sentence.

False-positive controls:
- Short ALL-CAPS acronyms (IS/AS) can be treated as case-sensitive.
- Word-boundary checks prevent 'is y' matching 'is yellow'.
- IGNORE_WORDS can drop generic single-token entities.
"""

from __future__ import annotations
import csv
import re
from collections import Counter, defaultdict
from typing import Any, Dict, List, Optional, Set, Tuple
import logging

from text_norm import normalize_with_map, tokens

def _looks_like_all_caps_acronym(raw: str, max_len: int) -> bool:
    s = (raw or "").strip()
    if not s:
        return False
    alnum = re.sub(r"[^A-Za-z0-9]", "", s)
    if not alnum.isalpha():
        return False
    if len(alnum) > max_len:
        return False
    letters = re.sub(r"[^A-Za-z]", "", s)
    return bool(letters) and letters.upper() == letters

def _parse_ignore_words(ignore_words: Optional[str]) -> Set[str]:
    if not ignore_words:
        return set()
    parts = re.split(r"[;,\s]+", ignore_words.strip())
    out: Set[str] = set()
    for p in parts:
        p = p.strip()
        if not p:
            continue
        norm, _ = normalize_with_map(p)
        out.update(tokens(norm))
    return out

def _autodetect_sanctions_column(fieldnames: List[str]) -> str:
    for c in fieldnames:
        if "sanction" in c.lower():
            return c
    lowered = {c.lower(): c for c in fieldnames}
    for candidate in ("sanction_list", "sanctions", "sanction list", "sanction"):
        if candidate in lowered:
            return lowered[candidate]
    raise ValueError(f"Could not auto-detect sanctions column. Columns: {fieldnames}")

def load_and_index_sanctions(
    csv_path: str,
    *,
    column_name: Optional[str] = None,
    ignore_words: Optional[str] = None,
    acronym_max_len: int = 3,
    logger: Optional[logging.Logger] = None,
) -> Tuple[List[Dict[str, Any]], Dict[str, List[int]]]:
    log = logger or logging.getLogger(__name__)
    ignore_set = _parse_ignore_words(ignore_words)

    phrases: List[Dict[str, Any]] = []
    seen_norm: Set[str] = set()
    df = Counter()

    with open(csv_path, "r", newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames:
            raise ValueError("CSV has no header")
        col = column_name or _autodetect_sanctions_column(reader.fieldnames)
        if col not in reader.fieldnames:
            raise ValueError(f"Sanctions column '{col}' not found. Columns: {reader.fieldnames}")

        rows = 0
        raw_entities = 0
        for row in reader:
            rows += 1
            cell = (row.get(col) or "").strip()
            if not cell:
                continue
            for part in cell.split(";"):
                raw_entities += 1
                raw = part.strip()
                if not raw:
                    continue

                case_sensitive = _looks_like_all_caps_acronym(raw, acronym_max_len)
                norm, _ = normalize_with_map(raw)

                if not norm or norm in seen_norm:
                    continue

                toks = tuple(tokens(norm))
                if not toks:
                    continue

                # Ignore generic single-token entries unless they are acronyms (ALL CAPS).
                if len(toks) == 1 and toks[0] in ignore_set and not case_sensitive:
                    continue

                phrases.append({"raw": raw, "norm": norm, "toks": toks, "case_sensitive": case_sensitive})
                seen_norm.add(norm)
                df.update(set(toks))

    anchor_index: Dict[str, List[int]] = defaultdict(list)
    for i, p in enumerate(phrases):
        anchor = min(set(p["toks"]), key=lambda t: df.get(t, 10**9))
        anchor_index[anchor].append(i)

    log.info(
        "Loaded sanctions: unique=%d anchors=%d ignoreTokens=%d column=%s",
        len(phrases), len(anchor_index), len(ignore_set), col
    )
    return phrases, dict(anchor_index)
