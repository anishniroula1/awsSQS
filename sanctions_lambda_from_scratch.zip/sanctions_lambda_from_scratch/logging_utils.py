"""logging_utils.py

Central logging configuration used by both Lambda and local runner.
"""

from __future__ import annotations
import logging

def configure_logger(name: str, level: str = "INFO") -> logging.Logger:
    """
    Configure and return a logger.

    Lambda note:
      Lambda may reuse execution environments (warm starts). This function avoids
      adding duplicate handlers by relying on `basicConfig` only once.
    """
    log = logging.getLogger(name)
    if not log.handlers:
        logging.basicConfig(
            level=getattr(logging, level.upper(), logging.INFO),
            format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        )
    return log

