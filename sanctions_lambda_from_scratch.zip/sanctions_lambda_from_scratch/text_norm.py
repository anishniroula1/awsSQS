"""text_norm.py

Normalization + tokenization used for exact matching.

Why normalize?
- Punctuation and casing differ between sanctions list and sentence text.
- Normalization makes exact matching robust without fuzzy matching.

We also produce an index map from normalized indices -> original indices
so we can report begin/end offsets in the original sentence.
"""

from __future__ import annotations
import re
from typing import List, Tuple

TOKEN_RE = re.compile(r"[a-z0-9]+", re.IGNORECASE)

def normalize_with_map(text: str) -> Tuple[str, List[int]]:
    """Return (normalized_text, norm_index_to_original_index)."""
    norm_chars: List[str] = []
    idx_map: List[int] = []
    prev_space = False

    for i, ch in enumerate(text or ""):
        c = ch.lower()
        if c.isalnum():
            norm_chars.append(c)
            idx_map.append(i)
            prev_space = False
        else:
            if norm_chars and not prev_space:
                norm_chars.append(" ")
                idx_map.append(i)
                prev_space = True

    if norm_chars and norm_chars[-1] == " ":
        norm_chars.pop()
        idx_map.pop()

    return "".join(norm_chars), idx_map

def tokens(norm_text: str):
    return TOKEN_RE.findall(norm_text or "")
