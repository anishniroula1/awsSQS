"""local_runner.py

Local runner (no S3).
"""

from __future__ import annotations
import argparse
import json
from logging_utils import configure_logger
from pipeline import run_pipeline_files

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sanctions-csv", required=True)
    ap.add_argument("--mapping-json", required=True)
    ap.add_argument("--comprehend-tar", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--sanctions-column", default=None)
    ap.add_argument("--ignore-words", default=None)
    ap.add_argument("--acronym-max-len", type=int, default=3)
    ap.add_argument("--max-candidates", type=int, default=50000)
    ap.add_argument("--return-all-sentences", action="store_true")
    ap.add_argument("--comprehend-tar-member", default=None)
    args = ap.parse_args()

    log = configure_logger("sanctions-local", "INFO")

    payload = run_pipeline_files(
        sanctions_csv_path=args.sanctions_csv,
        mapping_json_path=args.mapping_json,
        comprehend_tar_gz_path=args.comprehend_tar,
        sanctions_column=args.sanctions_column,
        ignore_words=args.ignore_words,
        acronym_max_len=args.acronym_max_len,
        max_candidates=args.max_candidates,
        return_all_sentences=args.return_all_sentences,
        comprehend_tar_member=args.comprehend_tar_member,
        logger=log,
    )

    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    log.info("Wrote %s", args.out)
    log.info("Meta %s", payload["meta"])

if __name__ == "__main__":
    main()
