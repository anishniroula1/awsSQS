"""comprehend_parse.py

Parse Comprehend JSONL records into per-line entities.

Robustness:
- Line number can be under different keys (Line, LineNumber, etc)
- Entities can be nested (Result->Entities, etc)
"""

from __future__ import annotations
import json
from typing import Any, Dict, List, Optional, Tuple

LINE_KEYS = ("Line", "line", "LineNumber", "lineNumber", "LineNo", "lineNo", "linenumber")
ENT_KEYS = ("Entities", "entities", "EntityList", "entityList")

def _find_entities(obj: Any) -> Optional[List[Dict[str, Any]]]:
    if obj is None:
        return None
    if isinstance(obj, list):
        if all(isinstance(x, dict) for x in obj):
            return obj
        return None
    if not isinstance(obj, dict):
        return None

    for k in ENT_KEYS:
        v = obj.get(k)
        if isinstance(v, list):
            return v

    for k in ("Result", "result", "Response", "response", "Output", "output"):
        if k in obj:
            found = _find_entities(obj[k])
            if found is not None:
                return found
    return None

def _extract_line_number(obj: Any, fallback: int) -> int:
    if isinstance(obj, dict):
        for k in LINE_KEYS:
            if k in obj:
                try:
                    return int(obj[k])
                except Exception:
                    pass
        loc = obj.get("Location") or obj.get("location")
        if isinstance(loc, dict):
            for k in LINE_KEYS:
                if k in loc:
                    try:
                        return int(loc[k])
                    except Exception:
                        pass
    return fallback

def read_jsonl_file(path: str) -> List[Any]:
    out: List[Any] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            out.append(json.loads(line))
    return out

def parse_jsonl_records(records: List[Any]) -> Tuple[List[Dict[str, Any]], Dict[str, int]]:
    lines: List[Dict[str, Any]] = []
    total_entities = 0
    with_explicit_line = 0

    for i, obj in enumerate(records, start=1):
        ln = _extract_line_number(obj, i)
        if isinstance(obj, dict) and any(k in obj for k in LINE_KEYS):
            with_explicit_line += 1

        ents = _find_entities(obj) or []
        norm_ents = []
        for e in ents:
            if not isinstance(e, dict):
                continue
            norm_ents.append({
                "Text": e.get("Text") or e.get("text"),
                "BeginOffset": e.get("BeginOffset") if e.get("BeginOffset") is not None else e.get("beginOffset"),
                "EndOffset": e.get("EndOffset") if e.get("EndOffset") is not None else e.get("endOffset"),
                "Type": e.get("Type") or e.get("type"),
                "Score": e.get("Score") if e.get("Score") is not None else e.get("score"),
            })
        total_entities += len(norm_ents)
        lines.append({"lineNumber": ln, "entities": norm_ents})

    meta = {"records": len(records), "entitiesTotal": total_entities, "recordsWithExplicitLine": with_explicit_line}
    return lines, meta
