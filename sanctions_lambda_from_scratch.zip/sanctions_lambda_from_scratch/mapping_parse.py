"""mapping_parse.py

Parses mapping JSON:
  [{"Line": 1, "content": "...", "sentence_id": "..."}, ...]
"""

from __future__ import annotations
from typing import Any, Dict, Tuple

def parse_mapping(mapping_obj: Any) -> Tuple[Dict[int, str], Dict[str, str], Dict[str, int]]:
    if isinstance(mapping_obj, dict):
        for k in ("items", "mappings", "data"):
            if k in mapping_obj and isinstance(mapping_obj[k], list):
                mapping_obj = mapping_obj[k]
                break

    if not isinstance(mapping_obj, list):
        raise ValueError("Mapping JSON must be a list")

    line_to_sid: Dict[int, str] = {}
    sid_to_content: Dict[str, str] = {}
    min_line = None
    max_line = None
    loaded = 0

    for it in mapping_obj:
        if not isinstance(it, dict):
            continue
        line = it.get("Line") if it.get("Line") is not None else it.get("line")
        sid = it.get("sentence_id") or it.get("sentenceId") or it.get("id")
        content = it.get("content")
        if line is None or sid is None or content is None:
            continue
        try:
            ln = int(line)
        except Exception:
            continue
        sid_s = str(sid)
        line_to_sid[ln] = sid_s
        sid_to_content[sid_s] = str(content)
        loaded += 1
        min_line = ln if min_line is None else min(min_line, ln)
        max_line = ln if max_line is None else max(max_line, ln)

    stats = {
        "mappingItems": len(mapping_obj),
        "mappingLoaded": loaded,
        "mappingMinLine": min_line or 0,
        "mappingMaxLine": max_line or 0,
    }
    return line_to_sid, sid_to_content, stats
