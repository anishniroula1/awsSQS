import json
import tarfile
from pathlib import Path
from comprehend_tar import extract_and_select_jsonl

def test_tar_selection_prefers_jsonl(tmp_path):
    manifest = tmp_path / "manifest.json"
    manifest.write_text(json.dumps({"status": "SUCCEEDED"}), encoding="utf-8")

    part = tmp_path / "part-00000"
    part.write_text(
        json.dumps({"Line": 1, "Entities": [{"Text": "A", "BeginOffset": 0, "EndOffset": 1}]}) + "\n" +
        json.dumps({"Line": 2, "Entities": []}) + "\n",
        encoding="utf-8"
    )

    tar_path = tmp_path / "output.tar.gz"
    with tarfile.open(tar_path, "w:gz") as tf:
        tf.add(manifest, arcname="manifest.json")
        tf.add(part, arcname="part-00000")

    chosen = extract_and_select_jsonl(str(tar_path), extract_dir=str(tmp_path / "x"))
    assert Path(chosen).name == "part-00000"
