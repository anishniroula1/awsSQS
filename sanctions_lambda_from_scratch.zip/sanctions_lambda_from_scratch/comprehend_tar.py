"""comprehend_tar.py

Extract and locate the **real** Comprehend JSONL inside output.tar.gz.

Common pitfall:
- output.tar.gz often contains a manifest JSON (single object) + JSONL parts (many lines with Entities).
- If you parse the manifest, you'll get 0 entities and empty results.

This module uses a scoring heuristic to pick the JSONL part file.
"""

from __future__ import annotations
import gzip
import json
import logging
import tarfile
from pathlib import Path
from typing import Optional, Tuple, List

ENT_KEYS = ("Entities", "entities", "EntityList", "entityList")

def _score_file(path: Path) -> Tuple[int, int]:
    try:
        data = path.read_bytes()[:128 * 1024]
    except Exception:
        return (0, 0)

    text = data.decode("utf-8", errors="ignore")
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    if not lines:
        return (0, 0)

    jsonl_bonus = 3 if len(lines) >= 5 else (1 if len(lines) >= 2 else 0)

    parsed = 0
    ent_hits = 0
    for ln in lines[:20]:
        try:
            obj = json.loads(ln)
        except Exception:
            continue
        if isinstance(obj, dict):
            parsed += 1
            if any(k in obj for k in ENT_KEYS):
                ent_hits += 1
            elif "Entities" in ln or "entities" in ln:
                ent_hits += 1

    score = ent_hits * 20 + parsed + jsonl_bonus
    return (score, parsed)

def extract_and_select_jsonl(
    tar_gz_path: str,
    *,
    extract_dir: str = "/tmp/comprehend_extract",
    preferred_member: Optional[str] = None,
    logger: Optional[logging.Logger] = None,
) -> str:
    log = logger or logging.getLogger(__name__)
    out_dir = Path(extract_dir)

    if out_dir.exists():
        for p in sorted(out_dir.rglob("*"), reverse=True):
            if p.is_file():
                p.unlink()
            else:
                try:
                    p.rmdir()
                except Exception:
                    pass
    out_dir.mkdir(parents=True, exist_ok=True)

    if not tarfile.is_tarfile(tar_gz_path):
        log.warning("Not detected as tarfile; trying gzip fallback: %s", tar_gz_path)
        gz_out = out_dir / "comprehend_output.jsonl"
        with gzip.open(tar_gz_path, "rb") as f_in, open(gz_out, "wb") as f_out:
            f_out.write(f_in.read())
        return str(gz_out)

    with tarfile.open(tar_gz_path, "r:gz") as tf:
        members = tf.getmembers()
        if preferred_member:
            m = next((x for x in members if x.name == preferred_member), None)
            if not m:
                raise ValueError(f"preferred_member not found: {preferred_member}")
            tf.extract(m, path=str(out_dir))
            p = out_dir / m.name
            if not p.is_file() or p.stat().st_size == 0:
                raise ValueError(f"preferred_member extracted but empty: {preferred_member}")
            log.info("Selected tar member (forced): %s", m.name)
            return str(p)

        tf.extractall(path=str(out_dir))

    files: List[Path] = [p for p in out_dir.rglob("*") if p.is_file() and p.stat().st_size > 0]
    if not files:
        raise ValueError("No non-empty files extracted")

    scored = []
    for p in files:
        score, parsed = _score_file(p)
        scored.append((score, parsed, p.stat().st_size, p))
    scored.sort(key=lambda t: (t[0], t[1], t[2]), reverse=True)

    for score, parsed, size, p in scored[:8]:
        log.info("Tar candidate: %s score=%d parsedLines=%d bytes=%d", p.name, score, parsed, size)

    best = scored[0][3]
    log.info("Selected JSONL candidate: %s", best.name)
    return str(best)
