"""
matcher.py

Exact matching of sanctions entities against sentence text, returning begin/end offsets.

Important: "exact match" here is **exact under normalization**:
- Lowercase
- Keep alphanumeric
- Convert everything else to spaces
- Collapse repeated spaces

This gives you:
- Case-insensitive matches
- Punctuation-tolerant matches (e.g., "Exxon, Inc" matches "EXXON INC")

Performance strategy (critical for Lambda):
------------------------------------------
If you have 100k+ sanction entities, you cannot do:
  for each sentence:
    for each entity:
      check substring
That is O(S * E) and will time out.

Instead we do:
1) Build a token rarity map across all sanction phrases.
2) For each phrase, choose ONE "anchor token" = rarest token in that phrase.
3) Build index: anchor_token -> [phrase_ids]
4) For each sentence:
   - tokenize it
   - collect candidate phrase ids only for tokens that appear in the sentence
   - substring-search only those candidates

This massively reduces comparisons in practice.
"""

from __future__ import annotations

import csv
import logging
import re
import time
from dataclasses import dataclass
from collections import defaultdict, Counter
from typing import Dict, List, Tuple, Set, Any

TOKEN_RE = re.compile(r"[a-z0-9]+", re.IGNORECASE)

@dataclass(frozen=True)
class Phrase:
    """A sanctions entity in both raw and normalized form."""
    raw: str
    norm: str
    toks: Tuple[str, ...]

def normalize_with_map(s: str) -> Tuple[str, List[int]]:
    """
    Normalize string and build mapping from normalized index -> original index.

    We need this because we search in normalized space (case/punct tolerant),
    but offsets must be returned in the original sentence string.

    Example:
      sentence:  "EXXON, INC reported..."
      normalized:"exxon inc reported"
      map:       maps normalized character index -> original character index

    Returns
    -------
    norm : str
        Normalized string
    idx_map : list[int]
        idx_map[i] = original index for normalized character i
    """
    norm_chars: List[str] = []
    idx_map: List[int] = []
    prev_space = False

    for i, ch in enumerate(s):
        c = ch.lower()
        if c.isalnum():
            norm_chars.append(c)
            idx_map.append(i)
            prev_space = False
        else:
            # collapse separators into one space
            if norm_chars and not prev_space:
                norm_chars.append(" ")
                idx_map.append(i)
                prev_space = True

    # trim trailing space
    if norm_chars and norm_chars[-1] == " ":
        norm_chars.pop()
        idx_map.pop()

    return "".join(norm_chars), idx_map

def tokens(norm: str) -> List[str]:
    """Extract alphanumeric tokens from normalized string."""
    return TOKEN_RE.findall(norm)

def build_phrase_index_from_csv(
    csv_path: str,
    column_name: str = "sanction_list",
    logger: logging.Logger | None = None,
):
    """
    Load sanctions entities from a CSV and build an anchor-token index.

    CSV assumption:
    - The column `column_name` contains one or more entities separated by semicolons.
      Example cell: "Exxon, Inc;Limited Group;Jon Julu"

    Steps:
    1) Read each row
    2) Split the sanctions cell by ';'
    3) Normalize each entity
    4) Dedupe identical normalized entities (common in multi-row lists)
    5) Tokenize each entity
    6) Count token frequencies across all entities (rarity)
    7) For each entity pick the rarest token as the anchor
    8) Build index: anchor_token -> list of phrase IDs

    Why anchors?
    - When scanning a sentence, we only need to consider phrases whose anchor token appears in the sentence.
    - This avoids scanning every phrase for every sentence.

    Returns
    -------
    phrases : list[Phrase]
        All unique sanctions phrases.
    anchor_index : dict[str, list[int]]
        Map from anchor token to phrase indices.
    token_freq : Counter
        Frequency of tokens across phrases.
    """
    log = logger or logging.getLogger(__name__)
    t0 = time.time()

    seen_norm: Set[str] = set()
    phrases: List[Phrase] = []
    token_freq = Counter()

    with open(csv_path, "r", newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames or column_name not in reader.fieldnames:
            raise ValueError(f"CSV missing column '{column_name}'. Found columns: {reader.fieldnames}")

        row_count = 0
        raw_entity_count = 0
        for row in reader:
            row_count += 1
            cell = (row.get(column_name) or "").strip()
            if not cell:
                continue
            for item in cell.split(";"):
                raw_entity_count += 1
                raw = item.strip()
                if not raw:
                    continue

                norm, _ = normalize_with_map(raw)
                if not norm or norm in seen_norm:
                    continue
                seen_norm.add(norm)

                toks = tuple(tokens(norm))
                if not toks:
                    continue

                phrases.append(Phrase(raw=raw, norm=norm, toks=toks))
                token_freq.update(set(toks))

    anchor_index: Dict[str, List[int]] = defaultdict(list)
    for i, p in enumerate(phrases):
        anchor = min(set(p.toks), key=lambda t: token_freq.get(t, 10**9))
        anchor_index[anchor].append(i)

    log.info(
        "Sanctions loaded: rows=%d raw_entities=%d unique_entities=%d anchors=%d (%.2fs)",
        row_count, raw_entity_count, len(phrases), len(anchor_index), time.time() - t0
    )
    return phrases, dict(anchor_index), token_freq

def find_exact_matches(sentence: str, phrases, anchor_index, max_candidates: int = 50_000) -> List[Dict[str, Any]]:
    """
    Find all exact matches (under normalization) of sanction phrases in a sentence.

    Candidate shortlisting:
    - Tokenize the normalized sentence
    - For each token, collect phrase IDs from anchor_index[token]
    - This yields a candidate set much smaller than all phrases

    MAX_CANDIDATES (safety cap):
    - Limits how many candidate phrases we consider for ONE sentence.
    - Prevents pathological worst cases from timing out Lambda.
    - If reached, we stop collecting candidates and proceed with what we have.

    Offsets:
    - Search occurs on normalized sentence string
    - Offsets are converted back to original indices using normalize_with_map() index mapping

    Returns
    -------
    list[dict]
        Each dict contains: entity, beginOffset, endOffset, matchedText
    """
    sent_norm, sent_map = normalize_with_map(sentence)
    if not sent_norm:
        return []

    sent_toks = set(tokens(sent_norm))
    if not sent_toks:
        return []

    cand_ids: Set[int] = set()
    for t in sent_toks:
        ids = anchor_index.get(t)
        if ids:
            cand_ids.update(ids)
            if len(cand_ids) >= max_candidates:
                break

    if not cand_ids:
        return []

    results: List[Dict[str, Any]] = []
    for pid in cand_ids:
        p = phrases[pid]
        start = 0
        while True:
            pos = sent_norm.find(p.norm, start)
            if pos == -1:
                break
            end = pos + len(p.norm)
            if end > len(sent_map):
                break

            orig_start = sent_map[pos]
            orig_end = sent_map[end - 1] + 1

            results.append({
                "entity": p.raw,
                "beginOffset": orig_start,
                "endOffset": orig_end,
                "matchedText": sentence[orig_start:orig_end],
            })
            start = pos + 1

    results.sort(key=lambda r: (r["beginOffset"], -(r["endOffset"] - r["beginOffset"])))
    return results
