import csv
from matcher import normalize_with_map, build_phrase_index_from_csv, find_exact_matches


def test_normalize_with_map_basic():
    s = "EXXON, INC!"
    norm, m = normalize_with_map(s)
    assert norm == "exxon inc"
    # 'i' in 'inc' is original index 7; in normalized 'inc' begins at index 6
    assert m[6] == 7


def test_exact_match_offsets(tmp_path):
    csv_path = tmp_path / "sanctions.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["sanction_list"])
        w.writeheader()
        w.writerow({"sanction_list": "Exxon, Inc;Jon Julu"})
    phrases, anchor_index, _ = build_phrase_index_from_csv(str(csv_path), "sanction_list")

    sentence = "I met Jon Julu yesterday."
    hits = find_exact_matches(sentence, phrases, anchor_index)

    h = [x for x in hits if x["entity"] == "Jon Julu"][0]
    assert sentence[h["beginOffset"]:h["endOffset"]] == "Jon Julu"
