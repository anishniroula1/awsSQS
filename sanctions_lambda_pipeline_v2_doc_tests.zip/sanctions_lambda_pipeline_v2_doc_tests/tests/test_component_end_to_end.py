import json
import csv
import boto3
from moto import mock_aws

import app


def _put_object(s3, bucket: str, key: str, body: bytes, content_type: str = "application/octet-stream"):
    s3.put_object(Bucket=bucket, Key=key, Body=body, ContentType=content_type)


@mock_aws
def test_end_to_end_lambda_writes_output_to_s3(tmp_path, monkeypatch):
    s3 = boto3.client("s3", region_name="us-east-1")
    s3.create_bucket(Bucket="in-bucket")
    s3.create_bucket(Bucket="out-bucket")

    sanctions_csv = tmp_path / "sanctions.csv"
    with sanctions_csv.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["sanction_list"])
        w.writeheader()
        w.writerow({"sanction_list": "Exxon, Inc;Limited Group;Jon Julu"})
        w.writerow({"sanction_list": "Acme Holdings LLC;Some Other Name"})
    _put_object(s3, "in-bucket", "sanctions/sanctions.csv", sanctions_csv.read_bytes(), "text/csv")

    mapping = [
        {"Line": 1, "content": "I met Jon Julu yesterday.", "sentence_id": "s1"},
        {"Line": 2, "content": "EXXON INC reported earnings.", "sentence_id": "s2"},
        {"Line": 3, "content": "Nothing special here.", "sentence_id": "s3"},
    ]
    _put_object(s3, "in-bucket", "mapping/mapping.json", json.dumps(mapping).encode("utf-8"), "application/json")

    comp_lines = [
        {"Entities": [{"Text": "Jon Julu", "BeginOffset": 6, "EndOffset": 13, "Type": "PERSON", "Score": 0.99}]},
        {"Result": {"Entities": [{"Text": "EXXON INC", "BeginOffset": 0, "EndOffset": 9, "Type": "ORGANIZATION", "Score": 0.98}]}},
        {"Entities": [{"Text": "Nothing", "BeginOffset": 0, "EndOffset": 7, "Type": "OTHER", "Score": 0.50}]},
    ]
    jsonl = "\n".join(json.dumps(x) for x in comp_lines) + "\n"
    _put_object(s3, "in-bucket", "comprehend/out.jsonl", jsonl.encode("utf-8"), "application/jsonl")

    monkeypatch.setenv("SANCTIONS_BUCKET", "in-bucket")
    monkeypatch.setenv("SANCTIONS_KEY", "sanctions/sanctions.csv")
    monkeypatch.setenv("SANCTIONS_COLUMN", "sanction_list")

    monkeypatch.setenv("MAPPING_BUCKET", "in-bucket")
    monkeypatch.setenv("MAPPING_KEY", "mapping/mapping.json")

    monkeypatch.setenv("COMPREHEND_BUCKET", "in-bucket")
    monkeypatch.setenv("COMPREHEND_KEY", "comprehend/out.jsonl")

    monkeypatch.setenv("OUTPUT_BUCKET", "out-bucket")
    monkeypatch.setenv("OUTPUT_KEY", "results/final.json")

    monkeypatch.setenv("PREVIEW_N", "1")

    resp = app.lambda_handler({}, None)
    assert resp["outputWritten"] is True
    assert resp["meta"]["uniqueSentences"] == 3
    assert len(resp["preview"]) == 1

    out_obj = s3.get_object(Bucket="out-bucket", Key="results/final.json")
    payload = json.loads(out_obj["Body"].read().decode("utf-8"))

    by_id = {r["sentence_id"]: r for r in payload["results"]}
    assert "s1" in by_id and "s2" in by_id

    s1_ents = by_id["s1"]["entities"]
    jon = [e for e in s1_ents if "Jon" in e["text"]][0]
    assert jon["sanctionFlag"] is True
    assert "csv_sentence_match" in jon["sources"]
    assert "comprehend" in jon["sources"]

    s2_ents = by_id["s2"]["entities"]
    ex = [e for e in s2_ents if "EXXON" in e["text"]][0]
    assert ex["sanctionFlag"] is True
