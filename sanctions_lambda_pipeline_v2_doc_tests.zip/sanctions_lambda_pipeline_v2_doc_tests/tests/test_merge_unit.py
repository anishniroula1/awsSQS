from merge import merge_entities_for_sentence


def test_merge_dedup_union_sources():
    sentence = "I met Jon Julu yesterday."
    csv_matches = [{"entity": "Jon Julu", "beginOffset": 6, "endOffset": 13, "matchedText": "Jon Julu"}]
    comprehend_entities = [{"Text": "Jon Julu", "BeginOffset": 6, "EndOffset": 13, "Type": "PERSON", "Score": 0.99}]
    sanction_norm_set = {"jon julu"}

    merged = merge_entities_for_sentence(sentence, csv_matches, comprehend_entities, sanction_norm_set)
    assert len(merged) == 1
    m = merged[0]
    assert m["sanctionFlag"] is True
    assert set(m["sources"]) == {"csv_sentence_match", "comprehend"}
