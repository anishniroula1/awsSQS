"""
s3io.py

S3 I/O helpers for the Lambda pipeline.

We keep S3 operations in one module so:
- app.py stays focused on orchestration
- tests can patch or mock these functions easily if needed
- file download/upload logic is not duplicated across the codebase
"""

from __future__ import annotations

import json
import logging
from typing import Any, List, Optional

import boto3

# AWS Lambda Python runtimes include boto3 by default.
s3 = boto3.client("s3")


def download_to_tmp(bucket: str, key: str, filename: str, logger: Optional[logging.Logger] = None) -> str:
    """
    Download an S3 object to Lambda's ephemeral disk and return the local path.

    Why `/tmp`?
    - AWS Lambda provides a writable `/tmp` directory.
    - Many libraries (csv, json) work naturally with filesystem paths.
    - This avoids loading very large files fully into memory first.

    Parameters
    ----------
    bucket : str
        S3 bucket name.
    key : str
        S3 object key.
    filename : str
        Local filename to use under /tmp (e.g., 'sanctions.csv').
    logger : logging.Logger | None
        Optional logger for structured logs.

    Returns
    -------
    str
        The local filesystem path (e.g., '/tmp/sanctions.csv').
    """
    log = logger or logging.getLogger(__name__)
    local_path = f"/tmp/{filename}"
    log.info("Downloading s3://%s/%s -> %s", bucket, key, local_path)
    s3.download_file(bucket, key, local_path)
    return local_path


def read_json_file(path: str) -> Any:
    """Read a JSON file from disk and return the parsed object."""
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def read_jsonl_file(path: str) -> List[Any]:
    """
    Read a JSON Lines (JSONL) file into a list of parsed objects.

    JSONL format:
    - each line is a standalone JSON object
    - common for batch outputs like AWS Comprehend jobs

    Returns
    -------
    list
        Parsed JSON object per non-empty line.
    """
    out: List[Any] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            out.append(json.loads(line))
    return out


def upload_json(bucket: str, key: str, data: Any, logger: Optional[logging.Logger] = None) -> None:
    """
    Upload a Python object as JSON to S3.

    This is used to write the final pipeline results to S3.

    Notes
    -----
    - For extremely large outputs you may prefer streaming/multipart,
      but for typical workloads this is enough.
    """
    log = logger or logging.getLogger(__name__)
    body = json.dumps(data, ensure_ascii=False).encode("utf-8")
    log.info("Uploading JSON to s3://%s/%s (%d bytes)", bucket, key, len(body))
    s3.put_object(Bucket=bucket, Key=key, Body=body, ContentType="application/json")
