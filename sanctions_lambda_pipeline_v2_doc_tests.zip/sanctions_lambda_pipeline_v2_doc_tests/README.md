# Sanctions + Comprehend Lambda (Exact) — Function-based + Tests + Full Docstrings

This package contains a function-based (non-class) Lambda pipeline that:

- Downloads **sanctions CSV** from S3
- Downloads **Comprehend JSONL** from S3
- Downloads **mapping JSON** from S3 (your format: `{Line, content, sentence_id}`)
- Converts JSONL -> normalized JSON (per line: `{lineNumber, entities:[...]}`)
- Joins `lineNumber` -> `sentence_id` using mapping
- Runs **exact matching** of sanction entities inside mapping `content` and returns offsets
- Merges CSV matches + Comprehend entities
- Adds `sanctionFlag=true` when sanctioned
- Deduplicates records
- Optionally writes output back to S3

## Lambda handler
- `app.lambda_handler`

## Required environment variables
- `SANCTIONS_BUCKET`, `SANCTIONS_KEY`
- `COMPREHEND_BUCKET`, `COMPREHEND_KEY`
- `MAPPING_BUCKET`, `MAPPING_KEY`

Optional:
- `SANCTIONS_COLUMN` (default: `sanction_list`)
- `MAX_CANDIDATES` (default: `50000`)
- `PREVIEW_N` (default: `3`)
- `OUTPUT_BUCKET`, `OUTPUT_KEY` (if set, writes output to S3)

## Run tests locally
```bash
pip install -r requirements-dev.txt
pytest -q
```

Notes:
- `requirements.txt` is for Lambda (boto3 is included in AWS Lambda runtimes).
- `requirements-dev.txt` includes `pytest` + `moto` for component tests.
