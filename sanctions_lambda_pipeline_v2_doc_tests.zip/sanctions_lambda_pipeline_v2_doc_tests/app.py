"""
app.py (AWS Lambda)

Function-based Lambda handler that runs the full pipeline.

Downloads from S3:
- sanctions CSV
- comprehend JSONL
- mapping JSON (Line -> sentence_id + content)

Joins Comprehend by lineNumber -> sentence_id using mapping,
scans sentence content for sanction phrases with offsets,
merges + dedupes entities, and optionally writes final JSON to S3.

Handler: app.lambda_handler
"""

from __future__ import annotations

import os
import time
import logging
from typing import Any, Dict, List, Tuple

from s3io import download_to_tmp, read_json_file, read_jsonl_file, upload_json
from matcher import build_phrase_index_from_csv, find_exact_matches, normalize_with_map
from comprehend_parser import to_lines_entities_json
from merge import merge_entities_for_sentence


def _getenv(name: str, default: str | None = None) -> str:
    """Fetch environment variable with clear error if required and missing."""
    v = os.getenv(name)
    if (v is None or v == "") and default is None:
        raise RuntimeError(f"Missing required environment variable: {name}")
    return v if v not in (None, "") else str(default)


def _configure_logger() -> logging.Logger:
    """Configure and return a logger with a simple consistent format."""
    log = logging.getLogger("sanctions-lambda")
    if not log.handlers:
        logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
    return log


def _norm_only(s: str) -> str:
    """Normalize text using the same rules as exact matching."""
    n, _ = normalize_with_map(s or "")
    return n


def _load_mapping_items(obj: Any) -> List[Dict[str, Any]]:
    """Accept mapping JSON as list, wrapper dict, or a single item."""
    if isinstance(obj, list):
        return obj
    if isinstance(obj, dict):
        for k in ("mappings", "items", "data"):
            if k in obj and isinstance(obj[k], list):
                return obj[k]
        if "Line" in obj:
            return [obj]
    raise ValueError("Mapping JSON must be a list (or wrapper containing a list).")


def _parse_mapping(obj: Any) -> Tuple[Dict[int, str], Dict[str, str], int]:
    """Parse mapping JSON into line->sentence_id and sentence_id->content maps."""
    items = _load_mapping_items(obj)
    line_to_sid: Dict[int, str] = {}
    sid_to_content: Dict[str, str] = {}

    for it in items:
        if not isinstance(it, dict):
            continue
        line = it.get("Line") if it.get("Line") is not None else it.get("line")
        sid = it.get("sentence_id") or it.get("sentenceId") or it.get("id")
        content = it.get("content")

        if line is None or sid is None or content is None:
            continue
        try:
            line_i = int(line)
        except Exception:
            continue

        sid_s = str(sid)
        line_to_sid[line_i] = sid_s
        sid_to_content[sid_s] = str(content)

    return line_to_sid, sid_to_content, len(items)


def lambda_handler(event, context):
    log = _configure_logger()
    t0 = time.time()

    sanctions_bucket = _getenv("SANCTIONS_BUCKET")
    sanctions_key = _getenv("SANCTIONS_KEY")
    sanctions_col = _getenv("SANCTIONS_COLUMN", "sanction_list")

    comprehend_bucket = _getenv("COMPREHEND_BUCKET")
    comprehend_key = _getenv("COMPREHEND_KEY")

    mapping_bucket = _getenv("MAPPING_BUCKET")
    mapping_key = _getenv("MAPPING_KEY")

    output_bucket = os.getenv("OUTPUT_BUCKET")
    output_key = os.getenv("OUTPUT_KEY")

    # MAX_CANDIDATES: See matcher.find_exact_matches docstring.
    max_candidates = int(_getenv("MAX_CANDIDATES", "50000"))

    # PREVIEW_N: How many sentence results to include in Lambda response.
    preview_n = int(os.getenv("PREVIEW_N", "3"))

    sanctions_path = download_to_tmp(sanctions_bucket, sanctions_key, "sanctions.csv", logger=log)
    mapping_path = download_to_tmp(mapping_bucket, mapping_key, "mapping.json", logger=log)
    comprehend_path = download_to_tmp(comprehend_bucket, comprehend_key, "comprehend.jsonl", logger=log)

    log.info("Loading mapping JSON...")
    mapping_obj = read_json_file(mapping_path)
    line_to_sid, sid_to_content, mapping_items_count = _parse_mapping(mapping_obj)

    log.info("Loading Comprehend JSONL...")
    comp_objs = read_jsonl_file(comprehend_path)

    log.info("Normalizing Comprehend JSONL...")
    comprehend_lines = to_lines_entities_json(comp_objs)

    comprehend_by_sentence: Dict[str, List[Dict[str, Any]]] = {}
    for i, line in enumerate(comprehend_lines, start=1):
        sid = line_to_sid.get(i)
        if not sid:
            continue
        comprehend_by_sentence.setdefault(sid, []).extend(line.get("entities") or [])

    log.info("Building sanctions index from CSV...")
    phrases, anchor_index, _ = build_phrase_index_from_csv(sanctions_path, column_name=sanctions_col, logger=log)
    sanction_norm_set = set(_norm_only(p.raw) for p in phrases if p.raw)

    log.info("Scanning sentences for sanction hits...")
    csv_matches_by_id: Dict[str, List[Dict[str, Any]]] = {}
    total_csv_hits = 0
    for sid, text in sid_to_content.items():
        hits = find_exact_matches(text, phrases, anchor_index, max_candidates=max_candidates)
        if hits:
            csv_matches_by_id[sid] = hits
            total_csv_hits += len(hits)

    log.info("Merging and deduping...")
    final_results = []
    total_entities = 0
    sanctioned_entities = 0

    for sid, text in sid_to_content.items():
        merged = merge_entities_for_sentence(
            sentence_text=text,
            csv_matches=csv_matches_by_id.get(sid, []),
            comprehend_entities=comprehend_by_sentence.get(sid, []),
            sanction_norm_set=sanction_norm_set,
        )
        if merged:
            total_entities += len(merged)
            sanctioned_entities += sum(1 for e in merged if e.get("sanctionFlag"))
            final_results.append({"sentence_id": sid, "content": text, "entities": merged})

    payload = {
        "results": final_results,
        "meta": {
            "mappingItems": mapping_items_count,
            "uniqueSentences": len(sid_to_content),
            "comprehendLines": len(comp_objs),
            "sanctionsEntitiesLoaded": len(phrases),
            "csvSentenceHitCount": total_csv_hits,
            "sentencesWithCsvHits": len(csv_matches_by_id),
            "sentencesWithEntities": len(final_results),
            "totalEntities": total_entities,
            "sanctionedEntities": sanctioned_entities,
            "maxCandidates": max_candidates,
            "tookMs": int((time.time() - t0) * 1000),
        },
    }

    if output_bucket and output_key:
        upload_json(output_bucket, output_key, payload, logger=log)

    return {
        "meta": payload["meta"],
        "preview": payload["results"][:preview_n],
        "outputWritten": bool(output_bucket and output_key),
    }
